# -*- coding: utf-8 -*-
"""
视频字幕翻译工具 - VAD 时长感知版
支持：OpenAI API, LM Studio, Ollama
修复：确保翻译后时间戳与原始完全一致
增强：使用 Silero VAD 校准的 vad_duration 实现长度感知翻译
"""

import json
import os
import re
import sys
import time
import traceback
import socket
from enum import Enum
from typing import Optional, List, Dict, Any
from openai import OpenAI
from dotenv import load_dotenv
from loguru import logger

# 加载环境变量
load_dotenv()

# === 配置模型类型 ===
class ModelType(Enum):
    OPENAI = "openai"
    LM_STUDIO = "lm_studio"
    OLLAMA = "ollama"

# 从环境变量获取配置
MODEL_NAME = os.getenv('MODEL_NAME', 'qwen3:8b').strip()
API_BASE = os.getenv('OPENAI_API_BASE', '').strip()
API_KEY = os.getenv('OPENAI_API_KEY', '').strip()

# 自动检测模型类型
def detect_model_type() -> ModelType:
    """自动检测模型类型"""
    api_base_lower = API_BASE.lower()
    
    if not API_BASE:
        logger.info("未设置API_BASE，默认使用Ollama")
        return ModelType.OLLAMA
    
    if 'localhost' in api_base_lower or '127.0.0.1' in api_base_lower or '::1' in api_base_lower:
        if 'lm-studio' in api_base_lower or 'lmstudio' in api_base_lower or ':1234' in API_BASE:
            return ModelType.LM_STUDIO
        elif 'ollama' in api_base_lower or ':11434' in API_BASE:
            return ModelType.OLLAMA
        else:
            # 本地其他服务，默认为Ollama兼容模式
            return ModelType.OLLAMA
    else:
        # 远程API，默认为OpenAI兼容
        return ModelType.OPENAI

MODEL_TYPE = detect_model_type()

# === Ollama特定配置 ===
if MODEL_TYPE == ModelType.OLLAMA:
    # Ollama默认配置
    if not API_BASE:
        API_BASE = 'http://127.0.0.1:11434/v1'
    if not API_KEY:
        API_KEY = 'ollama'  # Ollama不需要真实key
    logger.info(f"✅ 使用Ollama模型: {MODEL_NAME}")
    
    # 确保使用127.0.0.1而不是localhost
    if 'localhost' in API_BASE.lower():
        API_BASE = API_BASE.replace('localhost', '127.0.0.1')
    
elif MODEL_TYPE == ModelType.LM_STUDIO:
    logger.info(f"📦 使用LM Studio模型: {MODEL_NAME}")
    
elif MODEL_TYPE == ModelType.OPENAI:
    logger.info(f"☁️  使用OpenAI兼容API模型: {MODEL_NAME}")

logger.info(f"🌐 API地址: {API_BASE}")

# === 配置选项 ===
# 是否拆分句子（设置为False以保持时间戳完全一致）
SPLIT_SENTENCES = False  # 重要：改为False以修复时间戳问题

# === 创建全局客户端 ===
def create_openai_client() -> OpenAI:
    """创建OpenAI客户端，针对不同模型类型优化配置"""
    
    # Ollama特殊配置
    if MODEL_TYPE == ModelType.OLLAMA:
        return OpenAI(
            base_url=API_BASE,
            api_key=API_KEY,
            timeout=180.0,  # 长超时
            max_retries=3   # 重试次数
        )
    
    # 其他模型类型
    return OpenAI(
        base_url=API_BASE,
        api_key=API_KEY,
        timeout=120.0
    )

# 全局客户端实例
_client: Optional[OpenAI] = None

def get_client() -> OpenAI:
    """获取或创建OpenAI客户端"""
    global _client
    if _client is None:
        _client = create_openai_client()
    return _client

# === 健康检查 ===
def check_model_health() -> bool:
    """检查模型是否可用"""
    
    # 1. 首先检查端口是否开放
    try:
        # 提取端口号
        port = 11434  # 默认端口
        match = re.search(r':(\d+)', API_BASE)
        if match:
            port = int(match.group(1))
        
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        result = sock.connect_ex(('127.0.0.1', port))
        sock.close()
        
        if result != 0:
            logger.error(f"❌ 端口 {port} 未开放")
            return False
        logger.info(f"✅ 端口 {port} 开放")
        
    except Exception as e:
        logger.error(f"❌ 端口检查失败: {e}")
        return False
    
    # 2. 测试API连接
    max_retries = 3
    for attempt in range(max_retries):
        try:
            logger.info(f"🧪 健康检查尝试 {attempt + 1}/{max_retries}")
            
            # 使用简单直接的测试
            import requests
            if MODEL_TYPE == ModelType.OLLAMA:
                # Ollama专用测试
                test_url = API_BASE.replace('/v1', '/api/tags')
                response = requests.get(test_url, timeout=10)
                
                if response.status_code == 200:
                    logger.info("✅ Ollama API 测试成功")
                    return True
                else:
                    logger.warning(f"API测试状态码: {response.status_code}")
                    
            else:
                # 其他模型使用OpenAI客户端测试
                test_client = create_openai_client()
                
                # 超短测试消息
                response = test_client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=[{"role": "user", "content": "ping"}],
                    max_tokens=5,
                    timeout=15
                )
                
                if response.choices[0].message.content:
                    logger.info(f"✅ 模型健康检查成功")
                    return True
                
        except requests.exceptions.Timeout:
            logger.warning(f"⏱️  健康检查超时 (尝试 {attempt + 1})")
        except requests.exceptions.ConnectionError:
            logger.warning(f"🔌 连接错误 (尝试 {attempt + 1})")
        except Exception as e:
            logger.warning(f"⚠️  健康检查异常 (尝试 {attempt + 1}): {e}")
        
        # 如果不是最后一次尝试，等待后重试
        if attempt < max_retries - 1:
            wait_time = 2 * (attempt + 1)
            logger.info(f"⏳ 等待 {wait_time} 秒后重试...")
            time.sleep(wait_time)
    
    logger.error("❌ 所有健康检查尝试失败")
    return False

def get_necessary_info(info: dict) -> dict:
    """从视频元数据中提取必要信息"""
    return {
        'title': info.get('title', ''),
        'uploader': info.get('uploader', ''),
        'description': info.get('description', ''),
        'upload_date': info.get('upload_date', ''),
        'categories': info.get('categories', []),
        'tags': info.get('tags', []),
    }

def ensure_transcript_length(transcript: str, max_length: int = 1500) -> str:
    """确保字幕文本不超过指定长度，过长时截取中间部分"""
    if len(transcript) <= max_length:
        return transcript
    
    # 更安全的截取方式
    mid = len(transcript) // 2
    half = max_length // 2
    start = max(0, mid - half)
    end = min(len(transcript), mid + half)
    return transcript[start:end]

def safe_json_parse(text: str) -> dict:
    """安全解析JSON，支持多种格式"""
    if not text:
        return {"title": "", "summary": ""}
    
    try:
        # 尝试直接解析
        return json.loads(text)
    except json.JSONDecodeError:
        # 尝试提取JSON部分
        json_patterns = [
            r'```json\s*(.*?)\s*```',  # 代码块
            r'```\s*(.*?)\s*```',      # 其他代码块
            r'\{.*\}',                 # 纯JSON
        ]
        
        for pattern in json_patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                json_text = match.group(1) if len(match.groups()) > 0 else match.group(0)
                try:
                    return json.loads(json_text.strip())
                except:
                    continue
        
        # 如果都不行，尝试手动提取
        title_match = re.search(r'"title"\s*:\s*"([^"]+)"', text)
        summary_match = re.search(r'"summary"\s*:\s*"([^"]+)"', text, re.DOTALL)
        
        if title_match and summary_match:
            return {
                "title": title_match.group(1),
                "summary": summary_match.group(1)
            }
        
        # 最后尝试查找title和summary字段
        if '"title"' in text and '"summary"' in text:
            lines = text.split('\n')
            title = ""
            summary = ""
            for line in lines:
                if '"title"' in line.lower():
                    title = line.split(':', 1)[-1].strip().strip('",')
                elif '"summary"' in line.lower():
                    summary = line.split(':', 1)[-1].strip().strip('",')
            
            if title or summary:
                return {"title": title, "summary": summary}
        
        # 如果连JSON格式都没有，尝试提取纯文本
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        if len(lines) >= 2:
            return {
                "title": lines[0],
                "summary": lines[1]
            }
        elif len(lines) == 1:
            return {
                "title": lines[0],
                "summary": lines[0]
            }
        
        return {"title": "", "summary": "无法解析内容"}

def get_model_params():
    """根据模型类型获取参数配置"""
    if MODEL_TYPE == ModelType.OLLAMA:
        return {
            'temperature': 0.3,
            'top_p': 0.9,
            'frequency_penalty': 0.0,
            'presence_penalty': 0.0,
        }
    elif MODEL_TYPE == ModelType.LM_STUDIO:
        return {
            'temperature': 0.3,
            'top_p': 0.9,
            'frequency_penalty': 0.0,
            'presence_penalty': 0.0,
        }
    else:  # OpenAI
        return {
            'temperature': 0.3,
            'top_p': 0.9,
            'frequency_penalty': 0.0,
            'presence_penalty': 0.0,
        }

def summarize_with_retry(
    info: dict,
    transcript: list,
    target_language: str = '简体中文',
    max_retries: int = 3
) -> dict:
    """生成视频摘要，包含健壮的错误处理"""
    
    # 准备字幕文本 - 限制长度避免错误
    transcript_text = ' '.join(line['text'] for line in transcript)
    transcript_text = ensure_transcript_length(transcript_text, max_length=1000)
    
    logger.info(f"📝 准备总结，字幕长度: {len(transcript_text)} 字符")
    
    # 根据模型类型调整提示词
    if MODEL_TYPE == ModelType.OLLAMA:
        # Ollama使用简单直接的提示词
        system_prompt = f"""你是一位专业翻译，请将英文翻译成地道、流畅的{target_language}。

要求：
1. **只输出翻译结果，不要包含任何英文、不要重复原文、不要添加说明**
2. **不要输出 "翻译："、"Translation:"、"Output:" 等任何前缀或后缀**
3. **不要用引号包裹翻译结果**
4. 如果原文是专有名词（如 DeepAgent, GPT），直接保留不翻译

示例：
输入: Hello world
输出: 你好，世界

输入: OpenAI GPT-4
输出: OpenAI GPT-4

现在请翻译以下内容，**只输出翻译文本**：
"""
    else:
        # OpenAI/LM Studio使用更详细的提示词
        system_prompt = f"你是一位专业的视频内容分析师。请提供详细准确的总结，用{target_language}回复。"
        
        prompt = f"""请为以下视频内容生成详细总结：

视频标题: "{info.get('title', '未知标题')}"

视频内容片段:
{transcript_text[:800]}...

请输出标准的JSON格式：
{{
  "title": "简洁的标题",
  "summary": "详细的内容摘要，涵盖视频的主要观点和信息"
}}

要求：
1. 用{target_language}回复
2. 确保summary包含视频的核心内容和关键信息"""
    
    client = get_client()
    model_params = get_model_params()
    
    for attempt in range(max_retries):
        try:
            logger.info(f"🔄 尝试生成总结 (第{attempt+1}次)...")
            
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
                timeout=60,
                **model_params  # 使用统一参数
            )
            
            summary_text = response.choices[0].message.content
            logger.debug(f"📄 原始总结输出: {summary_text[:200]}...")
            
            # 安全解析
            summary_data = safe_json_parse(summary_text)
            
            title = summary_data.get('title', '').strip()
            summary = summary_data.get('summary', '').strip()
            
            if not title or title == "无法解析内容":
                title = info.get('title', '')
            if not summary or summary == "无法解析内容":
                summary = "未能生成详细摘要"
            
            logger.info(f"✅ 总结生成成功: {title[:50]}...")
            
            result = {
                'title': title,
                'author': info.get('uploader', ''),
                'summary': summary,
                'tags': info.get('tags', []),
                'language': target_language,
                'model_type': MODEL_TYPE.value
            }
            
            return result
            
        except Exception as e:
            logger.warning(f"⚠️ 总结失败 (第{attempt+1}次): {e}")
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt
                logger.info(f"⏳ 等待 {wait_time} 秒后重试...")
                time.sleep(wait_time)
    
    # 所有重试失败，返回默认值
    logger.error("❌ 所有总结尝试失败，使用默认值")
    return {
        'title': info.get('title', ''),
        'author': info.get('uploader', ''),
        'summary': "视频内容摘要生成失败",
        'tags': info.get('tags', []),
        'language': target_language,
        'model_type': MODEL_TYPE.value
    }

def translation_postprocess(result: str) -> str:
    """对翻译结果进行后处理"""
    if not result:
        return ""
    
    # 安全地移除括号内容
    result = re.sub(r'\（[^)]*\）', '', result)
    result = re.sub(r'\([^)]*\)', '', result)
    
    # 替换省略号
    result = result.replace('...', '，')
    result = result.replace('..', '，')
    
    # 移除数字间的逗号
    result = re.sub(r'(?<=\d),(?=\d)', '', result)
    
    # 特殊字符替换
    replacements = {
        '²': '的平方',
        '————': '：',
        '——': '：',
        '°': '度',
        'AI': '人工智能',
        'transformer': 'Transformer',
        'Transformer': 'Transformer',
        'GPT': 'GPT',
        'LLM': '大语言模型',
        '\u200b': '',  # 零宽空格
        '\ufeff': '',  # BOM
    }
    
    for old, new in replacements.items():
        result = result.replace(old, new)
    
    # 清理多余空格
    result = re.sub(r'\s+', ' ', result).strip()
    
    return result

def safe_string_access(text: str, start: int, end: int) -> str:
    """安全地访问字符串切片"""
    if not text:
        return ""
    
    # 确保索引在范围内
    start = max(0, min(start, len(text)))
    end = max(0, min(end, len(text)))
    
    if start >= end:
        return ""
    
    return text[start:end]

def valid_translation(text: str, translation: str) -> tuple:
    """验证翻译结果的合法性"""
    if not translation:
        return False, "翻译结果为空"
    
    # 创建副本进行操作
    cleaned_translation = translation.strip()
    
    # 移除常见的前缀后缀
    prefixes = [
        '翻译：', '翻译:', '译文：', '译文:', 
        '输出：', '输出:', '结果：', '结果:',
        '响应：', '响应:', '回答：', '回答:',
        'assistant:', 'Assistant:',
    ]
    
    suffixes = ['。', '」', '"', "'", '》', '”', '」', '》', '>']
    
    for prefix in prefixes:
        if cleaned_translation.startswith(prefix):
            cleaned_translation = cleaned_translation[len(prefix):].strip()
    
    for suffix in suffixes:
        if cleaned_translation.endswith(suffix):
            cleaned_translation = cleaned_translation[:-len(suffix)].strip()
    
    # 安全地清理代码块
    if cleaned_translation.startswith('```') and cleaned_translation.endswith('```'):
        cleaned_translation = safe_string_access(cleaned_translation, 3, -3).strip()
    
    # 移除引号
    quotes_pairs = [
        ('"', '"'), ("'", "'"), 
        ('""', '""'), ("''", "''"), 
        ('《', '》'), ('「', '」'), 
        ('"', '"'), ('「', '」'),
        ('"', '"'), ('"', '"')
    ]
    
    for start_char, end_char in quotes_pairs:
        if (cleaned_translation.startswith(start_char) and 
            cleaned_translation.endswith(end_char) and
            len(cleaned_translation) >= len(start_char) + len(end_char)):
            cleaned_translation = safe_string_access(
                cleaned_translation, 
                len(start_char), 
                -len(end_char)
            ).strip()
    
    # 移除多余的前缀
    patterns = [
        r'^.*?翻译[：:]\s*',
        r'^.*?[：:]\s*',
        r'^"?\s*',
        r'^\s*',
        r'^[\"\']',
        r'[\"\']$'
    ]
    
    for pattern in patterns:
        cleaned_translation = re.sub(pattern, '', cleaned_translation, count=1)
    
    # 后处理
    cleaned_translation = translation_postprocess(cleaned_translation)
    
    if not cleaned_translation:
        return False, "处理后翻译为空"
    
    # 长度检查 - 对Ollama更宽松
    max_length_multiplier = 3.0 if MODEL_TYPE == ModelType.OLLAMA else 2.0
    
    if len(text) <= 10 and len(cleaned_translation) > 50:
        logger.warning(f"短文本翻译过长: {len(cleaned_translation)} > 50")
        # 不直接拒绝，可能专有名词
    
    if len(cleaned_translation) > len(text) * max_length_multiplier:
        return False, f"翻译过长: {len(cleaned_translation)} > {len(text)} * {max_length_multiplier}"
    
    # 禁止词检查 - 对Ollama放宽
    forbidden = ['翻译结果', '原文内容', '简体中文', '中文翻译', 
                'translate', 'Translate', '```json', 'JSON格式']
    
    if MODEL_TYPE != ModelType.OLLAMA:
        forbidden.extend(['assistant', 'system', 'user'])
    
    for word in forbidden:
        if word.lower() in cleaned_translation.lower():
            return False, f"包含禁止词: {word}"
    
    # 检查是否为有效翻译
    if re.search(r'[\u4e00-\u9fff]', cleaned_translation):
        return True, cleaned_translation
    elif cleaned_translation and len(cleaned_translation) > 0:
        # 如果没有中文字符但有内容，也接受（可能是专有名词）
        return True, cleaned_translation
    else:
        return False, "翻译内容无效"

def split_text_into_sentences(para: str) -> List[str]:
    """将段落拆分为句子列表"""
    if not para:
        return []
    
    # 使用中文句子分割
    sentences = re.split(r'(?<=[。！？?!\.])\s+', para)
    
    # 清理空句子和空白
    cleaned = [s.strip() for s in sentences if s.strip()]
    
    # 如果分割失败，返回原段落
    if not cleaned:
        return [para.strip()]
    
    return cleaned

def split_sentences_fixed(translation: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    将翻译结果按句子拆分，但保持原始时间戳范围不变
    修复时间戳问题，确保每个原始条目的总时长不变
    """
    output_data = []
    
    for item in translation:
        try:
            # 原始时间戳
            original_start = float(item.get('start', 0))
            original_end = float(item.get('end', 0))
            text = item.get('text', '')
            speaker = item.get('speaker', '')
            translation_text = item.get('translation', '').strip()
            
            if not translation_text:
                # 没有翻译，跳过
                continue
            
            # 拆分翻译文本
            sentences = split_text_into_sentences(translation_text)
            
            if not sentences or len(sentences) == 0:
                # 无法拆分，保留原始
                output_data.append({
                    "start": round(original_start, 3),
                    "end": round(original_end, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": translation_text
                })
                continue
            
            if len(sentences) == 1:
                # 只有一个句子，直接使用原始时间戳
                output_data.append({
                    "start": round(original_start, 3),
                    "end": round(original_end, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": sentences[0]
                })
                continue
            
            # ========== 关键修复：基于句子数量平均分配时间 ==========
            # 这样可以确保总时长不变
            total_sentences = len(sentences)
            original_duration = original_end - original_start
            
            if original_duration <= 0:
                # 无效时长，使用默认
                duration_per_sentence = 1.0 / total_sentences
            else:
                duration_per_sentence = original_duration / total_sentences
            
            current_time = original_start
            
            for i, sentence in enumerate(sentences):
                if not sentence:
                    continue
                
                # 计算结束时间
                if i == total_sentences - 1:
                    # 最后一句确保对齐到原始结束时间
                    end_time = original_end
                else:
                    end_time = current_time + duration_per_sentence
                
                # 确保时间合法
                end_time = min(end_time, original_end)
                if end_time <= current_time:
                    end_time = current_time + 0.01
                
                output_data.append({
                    "start": round(current_time, 3),
                    "end": round(end_time, 3),
                    "text": text,  # 保持原文不变
                    "speaker": speaker,
                    "translation": sentence
                })
                
                current_time = end_time
                
        except Exception as e:
            logger.error(f"❌ 句子拆分出错: {e}")
            # 出错时保留原样
            if 'translation_text' in locals() and translation_text:
                output_data.append({
                    "start": round(original_start, 3),
                    "end": round(original_end, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": translation_text
                })
    
    return output_data

def fix_timestamps(original_transcript: List[Dict[str, Any]], 
                  translated_transcript: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    强制修正时间戳，确保与原始完全一致
    这是最终的安全措施
    """
    if len(original_transcript) == 0:
        return translated_transcript
    
    # 创建一个映射，按text+speaker查找原始时间戳
    original_map = {}
    for orig in original_transcript:
        key = f"{orig.get('text', '')}_{orig.get('speaker', '')}"
        original_map[key] = {
            "start": round(float(orig.get('start', 0)), 3),
            "end": round(float(orig.get('end', 0)), 3)
        }
    
    fixed = []
    
    for trans in translated_transcript:
        text = trans.get('text', '')
        speaker = trans.get('speaker', '')
        key = f"{text}_{speaker}"
        
        if key in original_map:
            # 使用原始时间戳
            start = original_map[key]["start"]
            end = original_map[key]["end"]
        else:
            # 找不到对应，使用翻译中的时间戳
            start = round(float(trans.get('start', 0)), 3)
            end = round(float(trans.get('end', 0)), 3)
        
        fixed_item = {
            "start": start,
            "end": end,
            "text": text,
            "speaker": speaker,
            "translation": trans.get('translation', text)
        }
        
        fixed.append(fixed_item)
    
    return fixed

def validate_time_alignment(original: List[Dict[str, Any]], 
                          translated: List[Dict[str, Any]]) -> bool:
    """验证翻译后的时间戳是否与原始对齐"""
    
    if len(original) != len(translated):
        logger.warning(f"❌ 条目数量不匹配: 原始 {len(original)} vs 翻译 {len(translated)}")
        return False
    
    all_match = True
    
    for i, (orig, trans) in enumerate(zip(original, translated)):
        orig_start = round(float(orig.get('start', 0)), 3)
        orig_end = round(float(orig.get('end', 0)), 3)
        trans_start = round(float(trans.get('start', 0)), 3)
        trans_end = round(float(trans.get('end', 0)), 3)
        
        # 允许微小误差（0.001秒）
        if (abs(orig_start - trans_start) > 0.001 or 
            abs(orig_end - trans_end) > 0.001):
            logger.warning(f"⚠️ 第 {i+1} 条时间戳不匹配:")
            logger.warning(f"    原始: {orig_start} - {orig_end} (时长: {orig_end - orig_start:.3f}s)")
            logger.warning(f"    翻译: {trans_start} - {trans_end} (时长: {trans_end - trans_start:.3f}s)")
            all_match = False
    
    if all_match:
        logger.info("✅ 时间戳验证通过 - 所有时间戳完全一致")
    else:
        logger.warning("⚠️ 时间戳验证失败 - 部分时间戳不匹配")
    
    return all_match
def _translate(summary: dict, transcript: list, target_language: str = '简体中文') -> tuple:
    """
    返回: (translations: list, success_flags: list)
    success_flags[i] = True 表示第 i 句翻译成功
    """
    client = get_client()
    model_params = get_model_params()
    translation_params = model_params.copy()
    translation_params['temperature'] = 0.2

    if MODEL_TYPE == ModelType.OLLAMA:
        system_prompt = f"""你是一位专业翻译，请将英文翻译成地道、流畅的{target_language}。

要求：
1. 只输出翻译结果，不要添加任何解释、前缀或后缀
2. 保持专业术语的准确性
3. 确保翻译自然流畅
4. 如果原文是专有名词或无需翻译，直接输出原文
5. 请根据“有效语音时长”控制译文长度（短语音用短句，长语音可稍详细）
"""
    else:
        system_prompt = f"""你是一位专业翻译，请将英文翻译成地道、流畅的{target_language}。

要求：
1. 保持专业性和准确性
2. 翻译要自然、流畅、地道
3. 只输出翻译结果，不要添加任何解释或注释
4. 专有名词保持原样
5. 请根据“有效语音时长”控制译文长度
"""

    full_translation = []
    success_flags = []  # 新增：记录每句是否成功
    history = []
    total_lines = len(transcript)

    logger.info(f"📊 开始翻译，共 {total_lines} 句")

    for idx, line in enumerate(transcript):
        text = line.get('text', '').strip()
        if not text:
            full_translation.append("")
            success_flags.append(False)  # 空文本视为失败
            continue

        # 获取有效语音时长
        original_duration = float(line.get('end', 0)) - float(line.get('start', 0))
        vad_duration = line.get('vad_duration')
        if vad_duration is not None:
            actual_duration = min(float(vad_duration), original_duration)
            duration_info = f"(VAD校准后: {actual_duration:.1f}s)"
        else:
            actual_duration = original_duration
            duration_info = f"(原始时长: {actual_duration:.1f}s)"

        progress = (idx + 1) / total_lines * 100
        logger.info(f"📈 进度: {idx+1}/{total_lines} ({progress:.1f}%) {duration_info} - {text[:80]}...")

        translated = None
        translation_success = False
        max_retries = 3

        for retry in range(max_retries):
            try:
                user_message = f'原文: "{text}"\n有效语音时长: {actual_duration:.1f}秒\n请翻译成{target_language}，控制译文长度以匹配此时间。'
                messages = [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message}
                ]

                if history and len(history) > 0:
                    recent_history = history[-2:] if len(history) > 2 else history
                    messages = [messages[0]] + recent_history + [messages[1]]

                response = client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=messages,
                    max_tokens=len(text) * 4,
                    timeout=60,
                    **translation_params
                )

                raw_output = response.choices[0].message.content.strip()
                logger.debug(f"📥 原文: {text}")
                logger.debug(f"📤 原始输出: {raw_output}")

                success, clean_translation = valid_translation(text, raw_output)

                if success:
                    translated = clean_translation
                    translation_success = True
                    logger.info(f"✅ 译文 ({actual_duration:.1f}s): {clean_translation}")
                    history.append({"role": "user", "content": user_message})
                    history.append({"role": "assistant", "content": clean_translation})
                    if len(history) > 6:
                        history = history[-6:]
                    break
                else:
                    logger.warning(f"⚠️ 翻译验证失败 (第{retry+1}次): {clean_translation}")
                    if retry < max_retries - 1:
                        time.sleep(1)
                    else:
                        # 最后一次尝试简化版
                        try:
                            simple_response = client.chat.completions.create(
                                model=MODEL_NAME,
                                messages=[{"role": "user", "content": f'只翻译这句英文: "{text}"'}],
                                max_tokens=100,
                                timeout=30,
                                **translation_params
                            )
                            simple_translation = simple_response.choices[0].message.content.strip()
                            success, clean_translation = valid_translation(text, simple_translation)
                            if success:
                                translated = clean_translation
                                translation_success = True
                                logger.info(f"✅ 译文 ({actual_duration:.1f}s): {clean_translation}")
                            else:
                                translated = text
                                logger.info(f"⚠️ 回退到原文: {text}")
                        except:
                            translated = text
                            logger.info(f"⚠️ 回退到原文: {text}")

            except Exception as e:
                logger.error(f"❌ 翻译请求失败 (第{retry+1}次): {e}")
                if retry < max_retries - 1:
                    wait_time = 2 ** retry
                    logger.info(f"⏳ 等待 {wait_time} 秒后重试...")
                    time.sleep(wait_time)
                else:
                    translated = text
                    logger.info(f"⚠️ 回退到原文: {text}")

        full_translation.append(translated or text)
        success_flags.append(translation_success)
        
        if idx < total_lines - 1:
            if MODEL_TYPE == ModelType.OLLAMA:
                time.sleep(0.5)
            else:
                time.sleep(0.2)

    return full_translation, success_flags  # 返回两个值


def translate(folder: str, target_language: str = '简体中文') -> bool:
    """翻译单个视频的字幕，确保时间戳与原始完全一致"""
    try:
        translation_path = os.path.join(folder, 'translation.json')
        if os.path.exists(translation_path):
            logger.info(f"📂 已存在翻译，跳过: {folder}")
            return True

        info_path = os.path.join(folder, 'download.info.json')
        transcript_path = os.path.join(folder, 'transcript.json')
        
        if not os.path.exists(info_path) or not os.path.exists(transcript_path):
            logger.error(f"❌ 缺少必要文件")
            return False

        with open(info_path, 'r', encoding='utf-8') as f:
            raw_info = json.load(f)
        info = get_necessary_info(raw_info)

        with open(transcript_path, 'r', encoding='utf-8') as f:
            original_transcript = json.load(f)
        logger.info(f"📄 加载了 {len(original_transcript)} 条原始字幕")

        # 生成或加载 summary
        summary_path = os.path.join(folder, 'summary.json')
        if os.path.exists(summary_path):
            try:
                with open(summary_path, 'r', encoding='utf-8') as f:
                    summary = json.load(f)
                logger.info("📥 加载现有摘要")
            except Exception as e:
                logger.warning(f"⚠️ 加载摘要失败，重新生成: {e}")
                summary = summarize_with_retry(info, original_transcript, target_language)
                with open(summary_path, 'w', encoding='utf-8') as f:
                    json.dump(summary, f, indent=2, ensure_ascii=False)
        else:
            logger.info("🔄 生成新摘要")
            summary = summarize_with_retry(info, original_transcript, target_language)
            with open(summary_path, 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)

        # 翻译（获取结果 + 成功标志）
        logger.info("🚀 开始翻译字幕...")
        translations, success_flags = _translate(summary, original_transcript, target_language)  # ✅ 接收两个返回值

        # 创建副本
        working_transcript = []
        for i, line in enumerate(original_transcript):
            translation_text = translations[i] if i < len(translations) else line.get('text', '')
            working_line = {
                "start": float(line.get('start', 0)),
                "end": float(line.get('end', 0)),
                "text": line.get('text', ''),
                "speaker": line.get('speaker', ''),
                "translation": translation_text
            }
            working_transcript.append(working_line)

        if SPLIT_SENTENCES:
            logger.info("🔧 拆分长句（修复版）...")
            final_transcript = split_sentences_fixed(working_transcript)
        else:
            logger.info("📝 保持句子原样，不拆分...")
            final_transcript = working_transcript

        logger.info("🔍 强制修正时间戳以确保与原始一致...")
        final_transcript = fix_timestamps(original_transcript, final_transcript)
        logger.info("✅ 验证时间戳一致性...")
        validate_time_alignment(original_transcript, final_transcript)

        for item in final_transcript:
            item["start"] = round(float(item.get("start", 0)), 3)
            item["end"] = round(float(item.get("end", 0)), 3)

        # 保存
        with open(translation_path, 'w', encoding='utf-8') as f:
            json.dump(final_transcript, f, indent=2, ensure_ascii=False)
        logger.info(f"✅ 翻译完成: {translation_path}")

        # ===== 新增：详细翻译统计 =====
        total = len(success_flags)
        success_count = sum(success_flags)
        failure_count = total - success_count

        logger.info(f"\n{'='*60}")
        logger.info(f"📊 翻译结果统计:")
        logger.info(f"  总计: {total} 句")
        logger.info(f"  成功: {success_count} 句 ({success_count/total*100:.1f}%)")
        logger.info(f"  失败: {failure_count} 句 ({failure_count/total*100:.1f}%)")

        if failure_count > 0:
            logger.warning(f"\n⚠️  以下句子翻译失败（回退到原文）:")
            for i, (line, success) in enumerate(zip(original_transcript, success_flags)):
                if not success:
                    text = line.get('text', '')[:100]
                    start = line.get('start', 0)
                    end = line.get('end', 0)
                    logger.warning(f"  [{i+1}] {start:.1f}s-{end:.1f}s: {text}...")

        # 保存统计到文件（可选）
        stats_path = os.path.join(folder, 'translation_stats.json')
        stats = {
            'total_lines': total,
            'success_count': success_count,
            'failure_count': failure_count,
            'success_rate': round(success_count / total * 100, 2) if total > 0 else 0,
            'failed_lines': [
                {
                    'index': i,
                    'start': line.get('start'),
                    'end': line.get('end'),
                    'text': line.get('text', '')[:200]
                }
                for i, (line, success) in enumerate(zip(original_transcript, success_flags))
                if not success
            ]
        }
        with open(stats_path, 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)
        logger.info(f"📊 统计已保存: {stats_path}")
        # ===============================

        return True

    except Exception as e:
        logger.error(f"❌ 翻译失败: {e}")
        logger.error(traceback.format_exc())
        return False


def translate_all_transcript_under_folder(root_folder: str, target_language: str = '简体中文') -> int:
    """批量翻译指定文件夹下所有视频的字幕"""
    # 先检查模型健康
    logger.info("🔍 检查模型服务...")
    if not check_model_health():
        logger.error("❌ 模型服务不可用")
        return 0
    
    count = 0
    failed = 0
    video_folders = []
    
    # 收集所有需要翻译的视频
    logger.info(f"📂 扫描目录: {root_folder}")
    for root, dirs, files in os.walk(root_folder):
        if 'transcript.json' in files and 'translation.json' not in files:
            video_folders.append(root)
    
    logger.info(f"🎯 找到 {len(video_folders)} 个需要翻译的视频")
    
    if not video_folders:
        logger.info("✅ 所有视频都已翻译完成")
        return 0
    
    for i, folder in enumerate(video_folders):
        logger.info(f"\n{'='*60}")
        logger.info(f"🎬 处理视频 ({i+1}/{len(video_folders)}):")
        logger.info(f"📁 目录: {folder}")
        
        try:
            start_time = time.time()
            
            if translate(folder, target_language):
                count += 1
                elapsed = time.time() - start_time
                logger.info(f"✅ 完成 ({elapsed:.1f}秒)")
            else:
                failed += 1
                logger.error(f"❌ 失败")
        except Exception as e:
            failed += 1
            logger.error(f"❌ 处理异常: {e}")
            logger.error(traceback.format_exc())
        
        # 避免处理过快
        if i < len(video_folders) - 1:
            wait_time = 1
            logger.info(f"⏳ 等待 {wait_time} 秒处理下一个...")
            time.sleep(wait_time)
    
    logger.info(f"\n{'='*60}")
    logger.info(f"🏁 翻译完成")
    logger.info(f"📈 总计: {len(video_folders)} 个视频")
    logger.info(f"✅ 成功: {count} 个")
    logger.info(f"❌ 失败: {failed} 个")
    
    return count

# ==================== 主程序 ====================
if __name__ == '__main__':
    # 配置日志
    logger.remove()
    logger.add(
        sys.stderr,
        level="INFO",
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{message}</cyan>",
        colorize=True
    )
    
    # 也保存到文件
    logger.add(
        "translation.log",
        level="DEBUG",
        rotation="10 MB",
        retention="7 days",
        encoding="utf-8",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}"
    )
    
    print("\n" + "="*60)
    print("🎬 视频字幕翻译工具 - VAD 时长感知版")
    print("="*60)
    logger.info(f"📦 模型类型: {MODEL_TYPE.value}")
    logger.info(f"🤖 模型名称: {MODEL_NAME}")
    logger.info(f"🌐 API地址: {API_BASE}")
    logger.info(f"🔑 API Key: {'已设置' if API_KEY else '未设置'}")
    logger.info(f"🔧 句子拆分: {'启用' if SPLIT_SENTENCES else '禁用（推荐）'}")
    
    # 测试连接
    logger.info("🧪 测试连接中...")
    try:
        import requests
        test_url = API_BASE.replace('/v1', '/api/tags') if '/v1' in API_BASE else f"{API_BASE}/api/tags"
        response = requests.get(test_url, timeout=10)
        
        if response.status_code == 200:
            models = response.json().get('models', [])
            model_names = [m['name'] for m in models]
            logger.info(f"✅ 连接成功! 可用模型: {', '.join(model_names)}")
        else:
            logger.warning(f"⚠️ 连接测试状态码: {response.status_code}")
    except Exception as e:
        logger.warning(f"⚠️ 连接测试异常: {e}")
    
    print("="*60 + "\n")
    
    # 批量翻译整个目录
    success_count = translate_all_transcript_under_folder(
        r'videos',
        '简体中文'
    )
    
    if success_count > 0:
        logger.info(f"🎉 成功翻译 {success_count} 个视频")
    else:
        logger.info("ℹ️  没有需要翻译的视频或翻译失败")