"""
YouTube 视频下载工具（稳定版，无需 PO Token）

✅ 严格遵循 yt-dlp 官方 Wiki 最佳实践：
- 不强制使用 mweb（避免 PO Token 问题）
- 使用 `player_skip=webpage,configs` 防 Cookie 轮换
- 自动加载 cookies.txt（若存在）
- 优先使用 WebM 格式（当前最稳定，无需 PO Token）
- 支持音频/视频/合并/分离四种模式

⚠️ 注意：
- 必须提供有效的 `cookies.txt`（从无痕窗口导出，参考官方 Wiki）
- 建议使用小号，避免主账号被封（限流：~2000 视频/小时）

作者: [Your Name]
创建时间: 2025-12-29
"""

import os
import re
import time
from loguru import logger
import yt_dlp


def sanitize_title(title: str) -> str:
    """清理标题为安全文件名（兼容中文、英文、数字）"""
    if not title:
        return "Unknown"
    title = re.sub(r'[^\w\u4e00-\u9fff \d\-_]', ' ', title)
    title = re.sub(r'\s+', ' ', title).strip()
    return title[:100]


def _resolve_cookies(cookies_file: str | None) -> str | None:
    """自动检测 cookies.txt（优先使用传入路径，其次当前目录）"""
    if cookies_file and os.path.isfile(cookies_file):
        return cookies_file
    if os.path.isfile('cookies.txt'):
        return 'cookies.txt'
    return None


def _get_output_path(info: dict, folder_path: str, suffix: str = '') -> str:
    upload_date = info.get('upload_date') or '00000000'
    title = sanitize_title(info.get('title', 'Unknown'))
    uploader = sanitize_title(info.get('uploader', 'Unknown'))
    output_dir = os.path.join(folder_path, uploader, f"{upload_date} {title}")
    os.makedirs(output_dir, exist_ok=True)
    return os.path.join(output_dir, f'download{suffix}')


def _common_ydl_opts(cookies_file: str | None, sleep_secs: int = 5) -> dict:
    """返回所有下载共用的基础配置"""
    opts = {
        # ✅ 官方推荐：跳过 webpage/configs 防 VISITOR_INFO1_LIVE 轮换
        'extractor_args': {'youtube': {'player_skip': ['webpage', 'configs']}},
        'sleep_interval': sleep_secs,  # 防限流（5-10 秒）
        'quiet': False,
        'ignoreerrors': True,
        'retries': 3,
        'fragment_retries': 3,
        'no_warnings': False,
    }
    cookies = _resolve_cookies(cookies_file)
    if cookies:
        opts['cookiefile'] = cookies
        logger.debug(f"Using cookies from: {cookies}")
    else:
        logger.warning("No cookies.txt found. May fail on bot-protected videos.")
    return opts


# ======================
# 接口 1: 仅下载视频（无音频）
# ======================
def download_video_only(info: dict, folder_path: str, resolution: str = '1080p', cookies_file: str = None) -> str | None:
    output_path = _get_output_path(info, folder_path, '_video')
    if any(os.path.isfile(output_path + ext) for ext in ['.mp4', '.webm']):
        logger.info(f"Video already exists: {output_path}")
        return os.path.dirname(output_path)

    try:
        max_h = int(resolution.lower().rstrip('p'))
    except (ValueError, AttributeError):
        max_h = 1080

    ydl_opts = _common_ydl_opts(cookies_file)
    ydl_opts.update({
        'format': f'bestvideo[height<={max_h}][ext=webm]/bestvideo[height<={max_h}][ext=mp4]/bestvideo',
        'outtmpl': output_path,
        'writethumbnail': False,
        'writeinfojson': True,
    })

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([info['webpage_url']])
        logger.info(f"Video-only saved: {output_path}")
        return os.path.dirname(output_path)
    except Exception as e:
        logger.error(f"Video download failed: {e}")
        return None


# ======================
# 接口 2: 仅下载音频（无视频）
# ======================
def download_audio_only(info: dict, folder_path: str, cookies_file: str = None) -> str | None:
    output_path = _get_output_path(info, folder_path, '_audio')
    if any(os.path.isfile(output_path + ext) for ext in ['.m4a', '.webm']):
        logger.info(f"Audio already exists: {output_path}")
        return os.path.dirname(output_path)

    ydl_opts = _common_ydl_opts(cookies_file)
    ydl_opts.update({
        'format': 'bestaudio[ext=webm]/bestaudio[ext=m4a]/bestaudio',
        'outtmpl': output_path,
        'writethumbnail': False,
        'writeinfojson': True,
    })

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([info['webpage_url']])
        logger.info(f"Audio-only saved: {output_path}")
        return os.path.dirname(output_path)
    except Exception as e:
        logger.error(f"Audio download failed: {e}")
        return None


# ======================
# 接口 3: 下载并自动合并（MP4）
# ======================
def download_and_merge(info: dict, folder_path: str, resolution: str = '1080p', cookies_file: str = None) -> str | None:
    output_path = _get_output_path(info, folder_path)
    if os.path.isfile(output_path + '.mp4'):
        logger.info(f"Merged video exists: {output_path}.mp4")
        return os.path.dirname(output_path)

    try:
        max_h = int(resolution.lower().rstrip('p'))
    except (ValueError, AttributeError):
        max_h = 1080

    ydl_opts = _common_ydl_opts(cookies_file)
    ydl_opts.update({
        'format': (
            f'bestvideo[height<={max_h}][ext=webm]+bestaudio[ext=webm]/'
            f'bestvideo[height<={max_h}][ext=mp4]+bestaudio[ext=m4a]/'
            f'best[height<={max_h}]/best'
        ),
        'outtmpl': output_path + '.mp4',
        'merge_output_format': 'mp4',
        'writethumbnail': True,
        'writeinfojson': True,
    })

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([info['webpage_url']])
        logger.info(f"Merged video saved: {output_path}.mp4")
        return os.path.dirname(output_path)
    except Exception as e:
        logger.error(f"Merge download failed: {e}")
        return None


# ======================
# 接口 4: 下载分离文件（视频 + 音频）
# ======================
def download_separate_files(info: dict, folder_path: str, resolution: str = '1080p', cookies_file: str = None) -> str | None:
    v_dir = download_video_only(info, folder_path, resolution, cookies_file)
    time.sleep(2)
    a_dir = download_audio_only(info, folder_path, cookies_file)
    if v_dir and a_dir:
        logger.info(f"Separate files ready in: {v_dir}")
        return v_dir
    return None


# ======================
# 元数据提取（带 Cookie + player_skip）
# ======================
def get_video_infos(urls, num_videos: int = 5, cookies_file: str = None):
    if isinstance(urls, str):
        urls = [urls]
    ydl_opts = _common_ydl_opts(cookies_file)
    ydl_opts.update({
        'dumpjson': True,
        'playlistend': num_videos,
        'quiet': True,
    })

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        for url in urls:
            info = ydl.extract_info(url, download=False)
            if not info:
                continue
            entries = info.get('entries') or []
            if entries:
                yield from (e for e in entries if e)
            else:
                yield info


# ======================
# 主程序：执行全部三种下载模式
# ======================
if __name__ == '__main__':
    logger.add("download.log", rotation="10 MB")

    url = 'https://www.youtube.com/watch?v=Zcnt4UyuPUM'
    folder = 'videos'
    cookies = 'cookies.txt'

    for info in get_video_infos(url, cookies_file=cookies):
        if not info or not info.get('title'):
            continue

        logger.info(f"Processing: {info['title']}")

        # 1. 下载音频（用于 ASR / 翻译）
        download_audio_only(info, folder, cookies)

        # 2. 下载视频（无音频，用于画面分析）
        download_video_only(info, folder, resolution='1080p', cookies_file=cookies)

        # 3. 下载并合并完整视频（用于最终输出）
        download_and_merge(info, folder, resolution='1080p', cookies_file=cookies)

        # 可选：如果你只需要分离文件（不合并），用这行代替上面两行：
        # download_separate_files(info, folder, resolution='1080p', cookies_file=cookies)