# -*- coding: utf-8 -*-
"""
视频字幕翻译工具 - VAD 时长感知 + JSON约束 + 上下文增强版
支持：OpenAI API, LM Studio, Ollama
特性：
  ✅ 强制 JSON 输出（{"translation": "..."}）
  ✅ 上下文感知（前后各1句）
  ✅ VAD 时长感知长度控制
  ✅ 严格时间戳对齐
  ✅ 自动重试 + 回退机制
  ✅ 详细的翻译统计
  ✅ 打印翻译结果预览
"""

import json
import os
import re
import sys
import time
import traceback
import socket
from enum import Enum
from typing import Optional, List, Dict, Any, Tuple
from openai import OpenAI
from dotenv import load_dotenv
from loguru import logger

# 加载环境变量
load_dotenv()

# === 配置模型类型 ===
class ModelType(Enum):
    OPENAI = "openai"
    LM_STUDIO = "lm_studio"
    OLLAMA = "ollama"

MODEL_NAME = os.getenv('MODEL_NAME', 'zongwei/gemma3-translator:4b').strip()
API_BASE = os.getenv('OPENAI_API_BASE', '').strip()
API_KEY = os.getenv('OPENAI_API_KEY', '').strip()

def detect_model_type() -> ModelType:
    api_base_lower = API_BASE.lower()
    if not API_BASE:
        return ModelType.OLLAMA
    if 'localhost' in api_base_lower or '127.0.0.1' in api_base_lower:
        if 'lm-studio' in api_base_lower or ':1234' in API_BASE:
            return ModelType.LM_STUDIO
        elif 'ollama' in api_base_lower or ':11434' in API_BASE:
            return ModelType.OLLAMA
        else:
            return ModelType.OLLAMA
    return ModelType.OPENAI

MODEL_TYPE = detect_model_type()

# === 配置客户端 ===
if MODEL_TYPE == ModelType.OLLAMA:
    if not API_BASE:
        API_BASE = 'http://127.0.0.1:11434/v1'
    if not API_KEY:
        API_KEY = 'ollama'
    if 'localhost' in API_BASE.lower():
        API_BASE = API_BASE.replace('localhost', '127.0.0.1')
    logger.info(f"✅ 使用Ollama模型: {MODEL_NAME}")
elif MODEL_TYPE == ModelType.LM_STUDIO:
    logger.info(f"📦 使用LM Studio模型: {MODEL_NAME}")
else:
    logger.info(f"☁️  使用OpenAI兼容API模型: {MODEL_NAME}")
logger.info(f"🌐 API地址: {API_BASE}")

SPLIT_SENTENCES = False  # 保持时间戳一致

_client: Optional[OpenAI] = None

def create_openai_client() -> OpenAI:
    timeout = 180.0 if MODEL_TYPE == ModelType.OLLAMA else 120.0
    return OpenAI(base_url=API_BASE, api_key=API_KEY, timeout=timeout, max_retries=2)

def get_client() -> OpenAI:
    global _client
    if _client is None:
        _client = create_openai_client()
    return _client

# === 健康检查 ===
def check_model_health() -> bool:
    try:
        port = int(re.search(r':(\d+)', API_BASE).group(1)) if ':' in API_BASE else 11434
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.settimeout(3)
            if sock.connect_ex(('127.0.0.1', port)) != 0:
                logger.error(f"❌ 端口 {port} 未开放")
                return False
        logger.info(f"✅ 端口 {port} 开放")
    except Exception as e:
        logger.error(f"❌ 端口检查失败: {e}")
        return False

    import requests
    test_url = API_BASE.replace('/v1', '/api/tags') if MODEL_TYPE == ModelType.OLLAMA else f"{API_BASE}/models"
    try:
        resp = requests.get(test_url, timeout=5)
        if resp.status_code == 200:
            logger.info("✅ 模型服务健康")
            return True
    except:
        pass
    logger.error("❌ 模型服务不可用")
    return False

# === 辅助函数 ===
def get_necessary_info(info: dict) -> dict:
    return {k: info.get(k, '') for k in ['title', 'uploader', 'description', 'upload_date', 'categories', 'tags']}

def safe_json_parse_translation(text: str) -> str:
    """安全解析 {"translation": "..."}"""
    if not text:
        return ""
    try:
        data = json.loads(text)
        if isinstance(data, dict) and 'translation' in data:
            return str(data['translation']).strip()
    except:
        pass
    # 尝试提取 JSON 块
    match = re.search(r'\{.*"translation"\s*:\s*".*".*\}', text, re.DOTALL)
    if match:
        try:
            data = json.loads(match.group(0))
            return str(data['translation']).strip()
        except:
            pass
    return ""

def estimate_max_chars(actual_duration: float) -> int:
    """根据时长估算最大字符数（中文约4字/秒）"""
    return max(8, min(120, int(actual_duration * 4.5)))

def build_context_prompt(
    current_text: str,
    prev_text: str,
    next_text: str,
    actual_duration: float,
    target_language: str = '简体中文'
) -> str:
    max_chars = estimate_max_chars(actual_duration)
    context_parts = []
    if prev_text:
        context_parts.append(f"前一句: {prev_text}")
    context_parts.append(f"当前句: {current_text}")
    if next_text:
        context_parts.append(f"后一句: {next_text}")
    
    context_str = "\n".join(context_parts)
    return f"""你是一位专业翻译，请将英文翻译成地道、流畅的{target_language}。

要求：
1. 严格输出 JSON 格式：{{"translation": "你的译文"}}
2. 译文长度必须匹配语音时长（约 {actual_duration:.1f} 秒），最多 {max_chars} 个汉字
3. 不要添加任何解释、前缀、后缀或标点（除非原文有）
4. 专有名词（如 GPT, Transformer, DeepMind）保持原样
5. 利用上下文消除歧义（如代词、省略主语等）

上下文：
{context_str}

请输出 JSON："""

def get_model_params():
    return {
        'temperature': 0.1,       # 降低随机性
        'top_p': 0.9,
        'frequency_penalty': 0.0,
        'presence_penalty': 0.0,
    }

def _translate_single_with_json_retry(
    current_text: str,
    prev_text: str,
    next_text: str,
    actual_duration: float,
    target_language: str,
    max_retries: int = 3
) -> Tuple[str, bool]:
    client = get_client()
    model_params = get_model_params()
    system_prompt = "你必须输出严格合法的JSON格式，不要包含任何其他内容。"
    
    for attempt in range(max_retries):
        try:
            user_prompt = build_context_prompt(current_text, prev_text, next_text, actual_duration, target_language)
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=150,
                timeout=45,
                **model_params
            )
            raw_output = response.choices[0].message.content.strip()
            logger.debug(f"🔄 原始输出: {raw_output[:100]}...")
            
            translation = safe_json_parse_translation(raw_output)
            if translation:
                return translation, True
            else:
                logger.warning(f"⚠️ JSON解析失败 (第{attempt+1}次)")
        except Exception as e:
            logger.warning(f"⚠️ 请求失败 (第{attempt+1}次): {e}")
        if attempt < max_retries - 1:
            time.sleep(1.5)
    
    return current_text, False  # 回退到原文

def _translate(summary: dict, transcript: list, target_language: str = '简体中文') -> tuple:
    total_lines = len(transcript)
    logger.info(f"📊 开始翻译，共 {total_lines} 句（上下文感知 + JSON约束）")
    
    full_translation = []
    success_flags = []

    for idx, line in enumerate(transcript):
        text = line.get('text', '').strip()
        if not text:
            full_translation.append("")
            success_flags.append(False)
            continue

        # 获取上下文
        prev_text = transcript[idx - 1].get('text', '') if idx > 0 else ""
        next_text = transcript[idx + 1].get('text', '') if idx < total_lines - 1 else ""

        # 获取时长
        original_duration = float(line.get('end', 0)) - float(line.get('start', 0))
        vad_duration = line.get('vad_duration')
        actual_duration = min(float(vad_duration), original_duration) if vad_duration is not None else original_duration

        progress = (idx + 1) / total_lines * 100
        logger.info(f"📈 进度: {idx+1}/{total_lines} ({progress:.1f}%) ({actual_duration:.1f}s) - {text[:60]}...")

        translation, success = _translate_single_with_json_retry(
            current_text=text,
            prev_text=prev_text,
            next_text=next_text,
            actual_duration=actual_duration,
            target_language=target_language,
            max_retries=3
        )
        
        full_translation.append(translation)
        success_flags.append(success)
        
        # 打印翻译结果（仅DEBUG级别）
        if logger.level("DEBUG").no >= logger.level("DEBUG").no:
            logger.debug(f"📖 原文: {text}")
            logger.debug(f"💬 译文: {translation}")
            logger.debug("-" * 40)
        
        # 速率限制
        if MODEL_TYPE == ModelType.OLLAMA:
            time.sleep(0.3)
        else:
            time.sleep(0.1)

    return full_translation, success_flags

# === 以下函数保持不变（时间戳对齐、后处理、统计等）===
def translation_postprocess(result: str) -> str:
    if not result:
        return ""
    result = re.sub(r'\（[^)]*\）', '', result)
    result = re.sub(r'\([^)]*\)', '', result)
    result = result.replace('...', '，').replace('..', '，')
    result = re.sub(r'(?<=\d),(?=\d)', '', result)
    replacements = {
        '²': '的平方', '————': '：', '——': '：', '°': '度',
        'AI': '人工智能', 'transformer': 'Transformer', 'GPT': 'GPT',
        'LLM': '大语言模型', '\u200b': '', '\ufeff': '',
    }
    for old, new in replacements.items():
        result = result.replace(old, new)
    return re.sub(r'\s+', ' ', result).strip()

def split_text_into_sentences(para: str) -> List[str]:
    if not para: return [para] if para else []
    sentences = re.split(r'(?<=[。！？?!\.])\s+', para)
    return [s.strip() for s in sentences if s.strip()] or [para.strip()]

def split_sentences_fixed(translation: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    output_data = []
    for item in translation:
        try:
            original_start = float(item.get('start', 0))
            original_end = float(item.get('end', 0))
            text = item.get('text', '')
            speaker = item.get('speaker', '')
            translation_text = item.get('translation', '').strip()
            if not translation_text:
                continue
            sentences = split_text_into_sentences(translation_text)
            if len(sentences) <= 1:
                output_data.append({
                    "start": round(original_start, 3),
                    "end": round(original_end, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": translation_text if sentences else ""
                })
                continue
            total_sentences = len(sentences)
            original_duration = original_end - original_start
            duration_per_sentence = (original_duration / total_sentences) if original_duration > 0 else 1.0 / total_sentences
            current_time = original_start
            for i, sentence in enumerate(sentences):
                if not sentence: continue
                end_time = original_end if i == total_sentences - 1 else current_time + duration_per_sentence
                end_time = min(end_time, original_end)
                if end_time <= current_time:
                    end_time = current_time + 0.01
                output_data.append({
                    "start": round(current_time, 3),
                    "end": round(end_time, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": sentence
                })
                current_time = end_time
        except Exception as e:
            logger.error(f"❌ 句子拆分出错: {e}")
            output_data.append({
                "start": round(original_start, 3),
                "end": round(original_end, 3),
                "text": text,
                "speaker": speaker,
                "translation": translation_text
            })
    return output_data

def fix_timestamps(original: List[Dict[str, Any]], translated: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not original: return translated
    key_map = {(item['text'], item.get('speaker', '')): (item['start'], item['end']) for item in original}
    fixed = []
    for item in translated:
        key = (item['text'], item.get('speaker', ''))
        start, end = key_map.get(key, (item.get('start', 0), item.get('end', 0)))
        fixed.append({
            "start": round(float(start), 3),
            "end": round(float(end), 3),
            "text": item["text"],
            "speaker": item.get("speaker", ""),
            "translation": item.get("translation", item["text"])
        })
    return fixed

def validate_time_alignment(original: List[Dict[str, Any]], translated: List[Dict[str, Any]]) -> bool:
    if len(original) != len(translated):
        logger.warning(f"❌ 条目数量不匹配: {len(original)} vs {len(translated)}")
        return False
    for i, (orig, trans) in enumerate(zip(original, translated)):
        os, oe = round(float(orig['start']), 3), round(float(orig['end']), 3)
        ts, te = round(float(trans['start']), 3), round(float(trans['end']), 3)
        if abs(os - ts) > 0.001 or abs(oe - te) > 0.001:
            logger.warning(f"⚠️ 时间戳不匹配 {i}: {os}-{oe} vs {ts}-{te}")
            return False
    logger.info("✅ 时间戳完全一致")
    return True

def summarize_with_retry(
    info: dict,
    transcript: list,
    target_language: str = '简体中文',
    max_retries: int = 3
) -> dict:
    transcript_text = ' '.join(line['text'] for line in transcript)
    transcript_text = transcript_text[:1000]  # 截断
    title = info.get('title', '未知标题')
    prompt = f"""请为以下视频内容生成详细总结：

视频标题: "{title}"
内容片段: {transcript_text[:800]}...

输出标准JSON：
{{
  "title": "简洁标题",
  "summary": "详细摘要"
}}
用{target_language}回复。"""
    
    system_prompt = "你是一位专业的视频内容分析师。"
    client = get_client()
    model_params = get_model_params()
    
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[{"role":"system","content":system_prompt},{"role":"user","content":prompt}],
                max_tokens=500,
                timeout=60,
                **model_params
            )
            from .step030_translation_vad import safe_json_parse  # 复用已有函数
            summary_data = safe_json_parse(response.choices[0].message.content)
            return {
                'title': summary_data.get('title') or info.get('title', ''),
                'author': info.get('uploader', ''),
                'summary': summary_data.get('summary') or '摘要生成失败',
                'tags': info.get('tags', []),
                'language': target_language,
                'model_type': MODEL_TYPE.value
            }
        except Exception as e:
            logger.warning(f"⚠️ 摘要失败 (第{attempt+1}次): {e}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)
    return {
        'title': info.get('title', ''),
        'author': info.get('uploader', ''),
        'summary': '视频内容摘要生成失败',
        'tags': info.get('tags', []),
        'language': target_language,
        'model_type': MODEL_TYPE.value
    }

def print_translation_preview(translated_data: List[Dict[str, Any]], num_lines: int = 10):
    """打印翻译结果预览"""
    logger.info(f"\n🔍 翻译结果预览（前 {num_lines} 条）:")
    logger.info("="*80)
    for i, item in enumerate(translated_data[:num_lines]):
        start_time = item.get('start', 0)
        end_time = item.get('end', 0)
        original_text = item.get('text', '')
        translated_text = item.get('translation', '')
        
        logger.info(f"[{i+1:2d}] {start_time:.1f}s - {end_time:.1f}s")
        logger.info(f"     原文: {original_text}")
        logger.info(f"     译文: {translated_text}")
        logger.info("-" * 80)
    logger.info(f"✅ 共 {len(translated_data)} 条翻译完成")

# === 翻译主流程（保持不变）===
def translate(folder: str, target_language: str = '简体中文') -> bool:
    try:
        translation_path = os.path.join(folder, 'translation.json')
        if os.path.exists(translation_path):
            logger.info(f"📂 已存在翻译，跳过: {folder}")
            return True

        info_path = os.path.join(folder, 'download.info.json')
        transcript_path = os.path.join(folder, 'transcript.json')
        if not os.path.exists(info_path) or not os.path.exists(transcript_path):
            logger.error(f"❌ 缺少必要文件")
            return False

        with open(info_path, 'r', encoding='utf-8') as f:
            info = get_necessary_info(json.load(f))
        with open(transcript_path, 'r', encoding='utf-8') as f:
            original_transcript = json.load(f)
        logger.info(f"📄 加载了 {len(original_transcript)} 条原始字幕")

        # 处理摘要
        summary_path = os.path.join(folder, 'summary.json')
        if os.path.exists(summary_path):
            try:
                with open(summary_path, 'r', encoding='utf-8') as f:
                    summary = json.load(f)
                logger.info("📥 加载现有摘要")
            except:
                summary = summarize_with_retry(info, original_transcript, target_language)
                with open(summary_path, 'w', encoding='utf-8') as f:
                    json.dump(summary, f, indent=2, ensure_ascii=False)
        else:
            summary = summarize_with_retry(info, original_transcript, target_language)
            with open(summary_path, 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)

        # 翻译
        logger.info("🚀 开始翻译字幕...")
        translations, success_flags = _translate(summary, original_transcript, target_language)

        # 构建结果
        working_transcript = []
        for i, line in enumerate(original_transcript):
            trans_text = translations[i] if i < len(translations) else line.get('text', '')
            working_transcript.append({
                "start": float(line.get('start', 0)),
                "end": float(line.get('end', 0)),
                "text": line.get('text', ''),
                "speaker": line.get('speaker', ''),
                "translation": translation_postprocess(trans_text)
            })

        if SPLIT_SENTENCES:
            final_transcript = split_sentences_fixed(working_transcript)
        else:
            final_transcript = working_transcript

        final_transcript = fix_timestamps(original_transcript, final_transcript)
        validate_time_alignment(original_transcript, final_transcript)

        # 保存
        with open(translation_path, 'w', encoding='utf-8') as f:
            json.dump(final_transcript, f, indent=2, ensure_ascii=False)
        logger.info(f"✅ 翻译完成: {translation_path}")

        # 打印翻译预览
        print_translation_preview(final_transcript, num_lines=10)

        # 统计
        total = len(success_flags)
        success_count = sum(success_flags)
        stats = {
            'total_lines': total,
            'success_count': success_count,
            'failure_count': total - success_count,
            'success_rate': round(100 * success_count / total, 2) if total else 0,
            'failed_lines': [
                {'index': i, 'start': line['start'], 'end': line['end'], 'text': line['text'][:200]}
                for i, (line, ok) in enumerate(zip(original_transcript, success_flags)) if not ok
            ]
        }
        with open(os.path.join(folder, 'translation_stats.json'), 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)
        logger.info(f"📊 成功率: {stats['success_rate']:.1f}% ({success_count}/{total})")

        return True
    except Exception as e:
        logger.error(f"❌ 翻译失败: {e}")
        logger.error(traceback.format_exc())
        return False

def translate_all_transcript_under_folder(root_folder: str, target_language: str = '简体中文') -> int:
    if not check_model_health():
        return 0
    video_folders = [
        root for root, _, files in os.walk(root_folder)
        if 'transcript.json' in files and 'translation.json' not in files
    ]
    logger.info(f"🎯 找到 {len(video_folders)} 个需要翻译的视频")
    if not video_folders:
        logger.info("✅ 所有视频都已翻译完成")
        return 0

    count = 0
    for i, folder in enumerate(video_folders):
        logger.info(f"\n{'='*60}")
        logger.info(f"🎬 处理视频 ({i+1}/{len(video_folders)}): {folder}")
        if translate(folder, target_language):
            count += 1
            logger.info("✅ 完成")
        else:
            logger.error("❌ 失败")
        if i < len(video_folders) - 1:
            time.sleep(1)
    logger.info(f"\n🏁 共成功翻译 {count} 个视频")
    return count

# ==================== 主程序 ====================
if __name__ == '__main__':
    logger.remove()
    logger.add(sys.stderr, level="INFO", format="<green>{time:MM-DD HH:mm:ss}</green> | <level>{level: <6}</level> | <cyan>{message}</cyan>")
    # 添加 DEBUG 日志（用于显示详细翻译过程）
    logger.add("translation.log", level="DEBUG", rotation="10 MB", retention="7 days", encoding="utf-8")

    print("\n" + "="*60)
    print("🎬 视频字幕翻译工具 - VAD+JSON+上下文增强版")
    print("="*60)
    logger.info(f"📦 模型: {MODEL_TYPE.value} | {MODEL_NAME}")
    logger.info(f"🌐 API: {API_BASE}")
    logger.info(f"🔧 句子拆分: {'启用' if SPLIT_SENTENCES else '禁用'}")

    success_count = translate_all_transcript_under_folder('videos', '简体中文')
    if success_count:
        logger.info(f"🎉 成功翻译 {success_count} 个视频")
    else:
        logger.info("ℹ️  无新视频或全部失败")