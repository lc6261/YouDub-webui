# -*- coding: utf-8 -*-
"""
视频字幕翻译工具 - 优化版
支持：上下文感知翻译、JSON格式输出、智能重试
"""

import json
import os
import re
import sys
import time
import traceback
import socket
from enum import Enum
from typing import Optional, List, Dict, Any, Tuple
from openai import OpenAI
from dotenv import load_dotenv
from loguru import logger

# 加载环境变量
load_dotenv()

# === 配置选项 ===
class ModelType(Enum):
    OPENAI = "openai"
    LM_STUDIO = "lm_studio"
    OLLAMA = "ollama"

# 翻译模式配置
class TranslationMode(Enum):
    SINGLE = "single"          # 逐句翻译（原始模式）
    SLIDING_WINDOW = "sliding" # 滑动窗口上下文
    BATCH = "batch"            # 批次翻译
    
# 从环境变量获取配置
MODEL_NAME = os.getenv('MODEL_NAME', 'mistral:7b-instruct').strip()
API_BASE = os.getenv('OPENAI_API_BASE', '').strip()
API_KEY = os.getenv('OPENAI_API_KEY', '').strip()
TRANSLATION_MODE = os.getenv('TRANSLATION_MODE', 'sliding').strip()  # single, sliding, batch
CONTEXT_WINDOW_SIZE = int(os.getenv('CONTEXT_WINDOW', '2'))
BATCH_SIZE = int(os.getenv('BATCH_SIZE', '5'))
SPLIT_SENTENCES = os.getenv('SPLIT_SENTENCES', 'False').lower() == 'true'
TARGET_LANGUAGE = os.getenv('TARGET_LANGUAGE', '简体中文').strip()

# 自动检测模型类型
def detect_model_type() -> ModelType:
    api_base_lower = API_BASE.lower()
    
    if not API_BASE:
        logger.info("未设置API_BASE，默认使用Ollama")
        return ModelType.OLLAMA
    
    if 'localhost' in api_base_lower or '127.0.0.1' in api_base_lower or '::1' in api_base_lower:
        if 'lm-studio' in api_base_lower or 'lmstudio' in api_base_lower or ':1234' in API_BASE:
            return ModelType.LM_STUDIO
        elif 'ollama' in api_base_lower or ':11434' in API_BASE:
            return ModelType.OLLAMA
        else:
            return ModelType.OLLAMA
    else:
        return ModelType.OPENAI

MODEL_TYPE = detect_model_type()

# === Ollama特定配置 ===
if MODEL_TYPE == ModelType.OLLAMA:
    if not API_BASE:
        API_BASE = 'http://127.0.0.1:11434/v1'
    if not API_KEY:
        API_KEY = 'ollama'
    logger.info(f"✅ 使用Ollama模型: {MODEL_NAME}")
    if 'localhost' in API_BASE.lower():
        API_BASE = API_BASE.replace('localhost', '127.0.0.1')
elif MODEL_TYPE == ModelType.LM_STUDIO:
    logger.info(f"📦 使用LM Studio模型: {MODEL_NAME}")
elif MODEL_TYPE == ModelType.OPENAI:
    logger.info(f"☁️  使用OpenAI兼容API模型: {MODEL_NAME}")

logger.info(f"🌐 API地址: {API_BASE}")
logger.info(f"🎯 翻译模式: {TRANSLATION_MODE}")
logger.info(f"🔧 目标语言: {TARGET_LANGUAGE}")

# === 创建全局客户端 ===
def create_openai_client() -> OpenAI:
    if MODEL_TYPE == ModelType.OLLAMA:
        return OpenAI(
            base_url=API_BASE,
            api_key=API_KEY,
            timeout=180.0,
            max_retries=3
        )
    return OpenAI(
        base_url=API_BASE,
        api_key=API_KEY,
        timeout=120.0
    )

_client: Optional[OpenAI] = None

def get_client() -> OpenAI:
    global _client
    if _client is None:
        _client = create_openai_client()
    return _client

# === 健康检查 ===
def check_model_health() -> bool:
    try:
        port = 11434
        match = re.search(r':(\d+)', API_BASE)
        if match:
            port = int(match.group(1))
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        result = sock.connect_ex(('127.0.0.1', port))
        sock.close()
        if result != 0:
            logger.error(f"❌ 端口 {port} 未开放")
            return False
        logger.info(f"✅ 端口 {port} 开放")
    except Exception as e:
        logger.error(f"❌ 端口检查失败: {e}")
        return False

    max_retries = 3
    for attempt in range(max_retries):
        try:
            logger.info(f"🧪 健康检查尝试 {attempt + 1}/{max_retries}")
            import requests
            if MODEL_TYPE == ModelType.OLLAMA:
                test_url = API_BASE.replace('/v1', '/api/tags')
                response = requests.get(test_url, timeout=10)
                if response.status_code == 200:
                    logger.info("✅ Ollama API 测试成功")
                    return True
                else:
                    logger.warning(f"API测试状态码: {response.status_code}")
            else:
                test_client = create_openai_client()
                response = test_client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=[{"role": "user", "content": "ping"}],
                    max_tokens=5,
                    timeout=15
                )
                if response.choices[0].message.content:
                    logger.info(f"✅ 模型健康检查成功")
                    return True
        except Exception as e:
            logger.warning(f"⚠️ 健康检查异常 (尝试 {attempt + 1}): {e}")
        if attempt < max_retries - 1:
            wait_time = 2 * (attempt + 1)
            logger.info(f"⏳ 等待 {wait_time} 秒后重试...")
            time.sleep(wait_time)
    logger.error("❌ 所有健康检查尝试失败")
    return False

# === 视频信息处理 ===
def get_enhanced_info(info: dict) -> dict:
    """从download.info.json获取增强信息"""
    enhanced = {
        'title': info.get('title', ''),
        'uploader': info.get('uploader', ''),
        'description': info.get('description', ''),
        'upload_date': info.get('upload_date', ''),
        'categories': info.get('categories', []),
        'tags': info.get('tags', []),
        'duration': info.get('duration', 0),
        'view_count': info.get('view_count', 0),
        'like_count': info.get('like_count', 0),
        'channel': info.get('channel', ''),
        'channel_id': info.get('channel_id', ''),
        'webpage_url': info.get('webpage_url', ''),
        'extractor': info.get('extractor', ''),
        'extractor_key': info.get('extractor_key', ''),
        'playlist': info.get('playlist', ''),
        'playlist_index': info.get('playlist_index'),
    }
    
    # 提取可能的主题和领域信息
    description = info.get('description', '')
    categories = info.get('categories', [])
    tags = info.get('tags', [])
    
    # 分析可能的领域
    domain_keywords = {
        'technology': ['python', 'programming', 'code', 'software', 'computer', 'ai', 'machine learning'],
        'science': ['physics', 'chemistry', 'biology', 'math', 'experiment', 'research'],
        'education': ['tutorial', 'lesson', 'course', 'learn', 'teaching', 'lecture'],
        'entertainment': ['movie', 'game', 'music', 'funny', 'comedy', 'show'],
        'business': ['finance', 'marketing', 'startup', 'investment', 'economy'],
    }
    
    domain_scores = {}
    all_text = f"{description} {' '.join(categories)} {' '.join(tags)}".lower()
    
    for domain, keywords in domain_keywords.items():
        score = sum(1 for keyword in keywords if keyword in all_text)
        if score > 0:
            domain_scores[domain] = score
    
    enhanced['domain'] = max(domain_scores.items(), key=lambda x: x[1])[0] if domain_scores else 'general'
    enhanced['domain_scores'] = domain_scores
    
    # 提取关键术语（从标签和标题中）
    potential_terms = set(tags)
    title_words = re.findall(r'\b[A-Z][a-z]*\b', info.get('title', ''))
    potential_terms.update(title_words)
    enhanced['potential_terms'] = list(potential_terms)[:20]
    
    return enhanced

# === 术语管理和缓存 ===
class TranslationManager:
    """翻译管理器，处理术语一致性和缓存"""
    
    def __init__(self):
        self.term_dict = {}  # 术语词典
        self.translation_cache = {}  # 翻译缓存
        self.context_memory = []  # 上下文记忆
        
    def extract_terms_from_text(self, text: str) -> List[str]:
        """从文本中提取可能的术语"""
        # 提取大写开头的单词（可能的专有名词）
        proper_nouns = re.findall(r'\b[A-Z][a-z]+\b', text)
        # 提取带连字符的技术术语
        hyphen_terms = re.findall(r'\b[a-zA-Z]+-[a-zA-Z]+\b', text)
        # 提取可能的缩写
        acronyms = re.findall(r'\b[A-Z]{2,}\b', text)
        
        terms = set(proper_nouns + hyphen_terms + acronyms)
        return list(terms)
    
    def update_from_video_info(self, video_info: dict):
        """从视频信息更新术语"""
        terms = video_info.get('potential_terms', [])
        for term in terms:
            if term and len(term) > 2:  # 只处理有意义的术语
                self.term_dict[term.lower()] = term  # 初始保持原样
    
    def get_term_hint(self) -> str:
        """获取术语提示文本"""
        if not self.term_dict:
            return ""
        
        term_list = [f"{k}: {v}" for k, v in self.term_dict.items() if k != v]
        if term_list:
            return f"\n术语表：\n" + "\n".join(term_list[:10])  # 限制数量
        return ""

# === 上下文提取函数 ===
def extract_context(transcript: List[Dict], current_index: int, window_size: int = 2) -> Dict[str, Any]:
    """
    提取上下文信息
    
    Args:
        transcript: 字幕列表
        current_index: 当前句子索引
        window_size: 上下文窗口大小
        
    Returns:
        包含前文、当前句和后文的字典
    """
    total = len(transcript)
    
    # 提取前文（最多window_size句）
    previous_sentences = []
    for i in range(max(0, current_index - window_size), current_index):
        if i < total:
            text = transcript[i].get('text', '').strip()
            if text:
                previous_sentences.append({
                    'index': i,
                    'text': text,
                    'distance': current_index - i
                })
    
    # 提取后文（最多window_size句）
    next_sentences = []
    for i in range(current_index + 1, min(total, current_index + window_size + 1)):
        if i < total:
            text = transcript[i].get('text', '').strip()
            if text:
                next_sentences.append({
                    'index': i,
                    'text': text,
                    'distance': i - current_index
                })
    
    # 当前句子
    current_sentence = transcript[current_index].get('text', '').strip() if current_index < total else ""
    
    return {
        'previous': previous_sentences[-2:] if len(previous_sentences) > 2 else previous_sentences,  # 最多2句前文
        'current': current_sentence,
        'next': next_sentences[:2] if len(next_sentences) > 2 else next_sentences,  # 最多2句后文
        'current_index': current_index,
        'total_sentences': total
    }

def format_context_for_prompt(context: Dict[str, Any]) -> str:
    """格式化上下文为提示词文本"""
    lines = []
    
    # 前文
    if context['previous']:
        lines.append("【前文上下文】:")
        for i, sentence in enumerate(context['previous'], 1):
            lines.append(f"  前文{i}: {sentence['text']}")
    
    # 当前句子
    lines.append(f"\n【当前句子】: {context['current']}")
    
    # 后文
    if context['next']:
        lines.append("\n【后文上下文】:")
        for i, sentence in enumerate(context['next'], 1):
            lines.append(f"  后文{i}: {sentence['text']}")
    
    return "\n".join(lines)

# === 提示词生成器 ===
def generate_translation_prompt(
    mode: str,
    video_info: dict,
    manager: TranslationManager,
    context: Dict[str, Any],
    duration: float = 0
) -> Tuple[str, str]:
    """根据模式和视频信息生成翻译提示词"""
    
    # 基础信息
    title = video_info.get('title', '视频内容')
    domain = video_info.get('domain', 'general')
    term_hint = manager.get_term_hint()
    
    # 领域特定的翻译风格
    domain_styles = {
        'technology': "技术文档风格，准确严谨，专业术语一致",
        'science': "学术论文风格，精确规范，逻辑清晰",
        'education': "教学讲解风格，通俗易懂，重点突出",
        'business': "商务报告风格，正式得体，表达清晰",
        'entertainment': "通俗口语风格，生动有趣，自然流畅",
        'general': "通用口语风格，自然流畅，表意清晰"
    }
    
    style = domain_styles.get(domain, domain_styles['general'])
    
    # 格式化上下文
    context_summary = format_context_for_prompt(context)
    
    if mode == 'batch':
        # 批次模式（保持原有逻辑）
        system_prompt = f"""你是一位专业的视频字幕翻译专家，专门负责将英文视频字幕翻译成{TARGET_LANGUAGE}。

视频信息：
- 标题：{title}
- 领域：{domain}
- 风格要求：{style}

{term_hint}

【最重要的指令】：
1. 输出必须是标准的JSON格式
2. 确保术语在整个视频中翻译一致
3. 翻译要自然流畅，符合{TARGET_LANGUAGE}表达习惯
4. 根据语音时长调整翻译长度

输出格式（仅限批次模式）：
{{
  "translations": [
    {{"original": "原文1", "translation": "翻译1"}},
    {{"original": "原文2", "translation": "翻译2"}},
    ...
  ]
}}"""
        
        user_prompt = f"""请翻译以下视频字幕片段：

{context_summary}

请确保：
1. 术语一致性
2. 上下文连贯性
3. 语音时长适配

请输出完整的JSON格式翻译结果。"""
    
    elif mode == 'sliding':
        # 滑动窗口模式 - 使用JSON格式输出
        system_prompt = f"""你是一位专业的视频字幕翻译专家，负责将英文视频字幕翻译成{TARGET_LANGUAGE}。

视频信息：
- 标题：{title}
- 领域：{domain}
- 风格要求：{style}

{term_hint}

【关键翻译规则】：
1. **输出必须是标准的JSON格式**
2. 仔细分析上下文，确保代词指代正确
3. 保持专业术语的一致性
4. 翻译要自然流畅，符合{TARGET_LANGUAGE}表达习惯
5. 根据语音时长控制译文长度

【输出格式要求】：
{{
  "translation": "当前句子的翻译结果",
  "notes": "可选：任何需要注意的事项，如术语处理等"
}}

重要提示：
- 只需要翻译标记为【当前句子】的文本
- 输出必须是有效的JSON
- 不要添加任何JSON之外的内容"""

        user_prompt = f"""以下是视频字幕的上下文片段：

{context_summary}

语音时长：{duration:.1f}秒

请只翻译【当前句子】为{TARGET_LANGUAGE}，确保翻译与上下文连贯一致。

输出必须是JSON格式，包含"translation"字段。"""
    
    else:  # single mode
        # 单句模式 - 使用JSON格式输出
        system_prompt = f"""你是一位专业翻译，请将英文翻译成地道、流畅的{TARGET_LANGUAGE}。

视频领域：{domain}
翻译风格：{style}

{term_hint}

【规则】：
1. **输出必须是标准的JSON格式**
2. 保持专业性和准确性
3. 翻译要自然、流畅、地道
4. 专有名词保持原样或根据上下文合理翻译
5. 根据语音时长控制译文长度

输出格式：
{{
  "translation": "翻译结果"
}}"""
        
        user_prompt = f'原文: "{context["current"]}"\n语音时长: {duration:.1f}秒\n请翻译成{TARGET_LANGUAGE}，控制译文长度以匹配此时间。输出必须是JSON格式。'
    
    return system_prompt, user_prompt

# === JSON解析和验证 ===
def parse_translation_json(response_text: str, expected_original: str = "") -> Tuple[bool, str, str]:
    """
    解析翻译JSON响应
    
    Args:
        response_text: 模型返回的文本
        expected_original: 预期的原文（用于验证）
        
    Returns:
        (成功标志, 翻译文本, 错误信息)
    """
    if not response_text:
        return False, "", "响应为空"
    
    # 清理响应文本
    cleaned_text = response_text.strip()
    
    # 尝试提取JSON
    json_patterns = [
        r'```json\s*(.*?)\s*```',
        r'```\s*(.*?)\s*```',
        r'\{.*\}',
    ]
    
    json_text = None
    for pattern in json_patterns:
        match = re.search(pattern, cleaned_text, re.DOTALL)
        if match:
            json_text = match.group(1) if len(match.groups()) > 0 else match.group(0)
            break
    
    if not json_text:
        json_text = cleaned_text
    
    try:
        # 解析JSON
        data = json.loads(json_text.strip())
        
        # 检查不同的JSON格式
        if 'translation' in data:
            translation = data['translation'].strip()
            if translation:
                return True, translation, ""
        
        elif 'translations' in data and isinstance(data['translations'], list):
            # 批次模式
            for item in data['translations']:
                if isinstance(item, dict) and 'original' in item and 'translation' in item:
                    if expected_original and item['original'].strip() == expected_original:
                        return True, item['translation'].strip(), ""
        
        return False, "", f"JSON格式不正确: {data.keys()}"
        
    except json.JSONDecodeError as e:
        return False, "", f"JSON解析失败: {e}"
    except Exception as e:
        return False, "", f"解析异常: {e}"

# === 翻译验证和后处理 ===
def translation_postprocess(result: str) -> str:
    """翻译后处理"""
    if not result:
        return ""
    
    # 移除括号内容
    result = re.sub(r'\（[^)]*\）', '', result)
    result = re.sub(r'\([^)]*\)', '', result)
    
    # 替换省略号
    result = result.replace('...', '，')
    result = result.replace('..', '，')
    
    # 数字中的逗号处理
    result = re.sub(r'(?<=\d),(?=\d)', '', result)
    
    # 特殊字符替换
    replacements = {
        '²': '的平方',
        '————': '：',
        '——': '：',
        '°': '度',
        'AI': '人工智能',
        'transformer': 'Transformer',
        'Transformer': 'Transformer',
        'GPT': 'GPT',
        'LLM': '大语言模型',
        '\u200b': '',
        '\ufeff': '',
    }
    for old, new in replacements.items():
        result = result.replace(old, new)
    
    # 标准化空格
    result = re.sub(r'\s+', ' ', result).strip()
    return result

def validate_translation(text: str, translation: str) -> Tuple[bool, str]:
    """验证翻译结果"""
    if not translation:
        return False, "翻译结果为空"
    
    cleaned = translation.strip()
    
    # 基础验证
    if not cleaned:
        return False, "翻译结果为空"
    
    # 检查是否还包含禁止内容
    forbidden_patterns = [
        r'^为[：:]',
        r'^翻译[：:]',
        r'^译文[：:]',
        r'^当前句子',
        r'^该句子',
        r'^这句话',
        r'^注意：',
        r'^请注意',
    ]
    
    for pattern in forbidden_patterns:
        if re.match(pattern, cleaned):
            return False, f"包含禁止内容: {pattern}"
    
    # 长度验证
    if len(cleaned) > len(text) * 4:
        return False, f"翻译过长: {len(cleaned)} > {len(text)} * 4"
    
    if len(text) > 10 and len(cleaned) < 2:
        return False, "翻译过短"
    
    # 基本内容检查
    if not re.search(r'[\u4e00-\u9fff\w\d]', cleaned):
        return False, "没有有效内容"
    
    return True, cleaned

# === 翻译引擎 ===
def translate_single_sentence(
    text: str,
    duration: float,
    video_info: dict,
    manager: TranslationManager
) -> str:
    """单句翻译"""
    client = get_client()
    
    # 创建上下文结构
    context = {
        'previous': [],
        'current': text,
        'next': [],
        'current_index': 0,
        'total_sentences': 1
    }
    
    system_prompt, user_prompt = generate_translation_prompt(
        'single', video_info, manager, context, duration
    )
    
    max_retries = 3
    for retry in range(max_retries):
        try:
            logger.debug(f"📤 发送翻译请求 (尝试 {retry+1}/{max_retries})")
            
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=len(text) * 3,
                timeout=30,
                temperature=0.2
            )
            
            raw_result = response.choices[0].message.content.strip()
            logger.debug(f"📥 收到响应: {raw_result[:200]}...")
            
            # 解析JSON
            json_success, translation, error_msg = parse_translation_json(raw_result, text)
            
            if json_success:
                # 验证翻译
                success, cleaned = validate_translation(text, translation)
                
                if success:
                    # 更新缓存
                    manager.translation_cache[text] = cleaned
                    logger.info(f"✅ 翻译成功: {cleaned[:100]}...")
                    return cleaned
                else:
                    logger.warning(f"⚠️ 翻译验证失败: {cleaned}")
                    if retry < max_retries - 1:
                        continue
            else:
                logger.warning(f"⚠️ JSON解析失败 (尝试 {retry+1}): {error_msg}")
                if retry < max_retries - 1:
                    time.sleep(1)
                    continue
                    
        except Exception as e:
            logger.error(f"❌ 翻译失败 (尝试 {retry+1}): {e}")
            if retry < max_retries - 1:
                time.sleep(1)
    
    logger.error("❌ 所有重试失败，返回原文")
    return text

def translate_with_context_window(
    transcript: List[Dict],
    video_info: dict,
    manager: TranslationManager,
    window_size: int = 2
) -> Tuple[List[str], List[bool]]:
    """滑动窗口上下文翻译 - 使用JSON格式"""
    client = get_client()
    full_translation = []
    success_flags = []
    
    total = len(transcript)
    logger.info(f"🚀 开始滑动窗口上下文翻译 (窗口大小: {window_size})")
    
    for idx in range(total):
        text = transcript[idx].get('text', '').strip()
        if not text:
            full_translation.append("")
            success_flags.append(False)
            continue
        
        # 计算时长
        original_duration = float(transcript[idx].get('end', 0)) - float(transcript[idx].get('start', 0))
        vad_duration = transcript[idx].get('vad_duration')
        actual_duration = min(float(vad_duration), original_duration) if vad_duration else original_duration
        
        # 提取上下文
        context = extract_context(transcript, idx, window_size)
        
        # 生成提示词
        system_prompt, user_prompt = generate_translation_prompt(
            'sliding', video_info, manager, context, actual_duration
        )
        
        progress = (idx + 1) / total * 100
        logger.info(f"📈 进度: {idx+1}/{total} ({progress:.1f}%) [{actual_duration:.1f}s]")
        logger.debug(f"📝 当前句子: {text[:60]}...")
        
        success = False
        translation = text  # 默认回退到原文
        
        max_retries = 3
        for retry in range(max_retries):
            try:
                logger.debug(f"🔄 翻译尝试 {retry+1}/{max_retries}")
                
                response = client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    max_tokens=len(text) * 4,
                    timeout=60,
                    temperature=0.2
                )
                
                raw_output = response.choices[0].message.content.strip()
                logger.debug(f"📥 原始输出: {raw_output[:200]}...")
                
                # 解析JSON
                json_success, parsed_translation, error_msg = parse_translation_json(raw_output, text)
                
                if json_success:
                    # 验证翻译
                    validation_success, cleaned = validate_translation(text, parsed_translation)
                    
                    if validation_success:
                        translation = cleaned
                        success = True
                        logger.info(f"✅ 翻译成功: {cleaned[:100]}...")
                        break
                    else:
                        logger.warning(f"⚠️ 翻译验证失败 (第{retry+1}次): {cleaned}")
                else:
                    logger.warning(f"⚠️ JSON解析失败 (第{retry+1}次): {error_msg}")
                
                if retry < max_retries - 1:
                    wait_time = 1 * (retry + 1)
                    logger.info(f"⏳ 等待 {wait_time} 秒后重试...")
                    time.sleep(wait_time)
                    
            except Exception as e:
                logger.error(f"❌ 翻译请求失败 (第{retry+1}次): {e}")
                if retry < max_retries - 1:
                    time.sleep(1)
        
        if not success:
            logger.warning("🔄 回退到单句翻译")
            translation = translate_single_sentence(text, actual_duration, video_info, manager)
            success = translation != text
        
        full_translation.append(translation)
        success_flags.append(success)
        
        # 控制请求频率
        if idx < total - 1:
            time.sleep(0.3 if MODEL_TYPE == ModelType.OLLAMA else 0.1)
    
    return full_translation, success_flags

def translate_in_batches(
    transcript: List[Dict],
    video_info: dict,
    manager: TranslationManager,
    batch_size: int = 5,
    overlap: int = 2
) -> Tuple[List[str], List[bool]]:
    """批次翻译"""
    client = get_client()
    full_translation = [""] * len(transcript)
    success_flags = [False] * len(transcript)
    
    total_batches = (len(transcript) + batch_size - 1) // batch_size
    
    for batch_idx in range(total_batches):
        start_idx = max(0, batch_idx * batch_size - overlap)
        end_idx = min(len(transcript), (batch_idx + 1) * batch_size + overlap)
        
        batch_items = transcript[start_idx:end_idx]
        target_indices = list(range(
            batch_idx * batch_size,
            min((batch_idx + 1) * batch_size, len(transcript))
        ))
        
        logger.info(f"📦 处理批次 {batch_idx+1}/{total_batches} "
                   f"[句子 {target_indices[0]+1}-{target_indices[-1]+1}]")
        
        # 构建批次内容
        batch_texts = []
        for i, item in enumerate(batch_items):
            full_idx = start_idx + i
            duration = float(item.get('end', 0)) - float(item.get('start', 0))
            vad_duration = item.get('vad_duration')
            actual_duration = min(float(vad_duration), duration) if vad_duration else duration
            
            batch_texts.append({
                "index": i,
                "full_index": full_idx,
                "text": item.get('text', ''),
                "duration": actual_duration,
                "is_target": full_idx in target_indices
            })
        
        # 构建上下文摘要
        context_lines = []
        for item in batch_texts:
            prefix = "【目标】" if item['is_target'] else "【上下文】"
            context_lines.append(f"{prefix}[{item['duration']:.1f}s] {item['text']}")
        
        context_summary = "\n".join(context_lines)
        
        # 创建虚拟上下文用于提示词生成
        context = {
            'previous': [],
            'current': f"批次翻译 {len(target_indices)} 个句子",
            'next': [],
            'current_index': 0,
            'total_sentences': len(batch_items)
        }
        
        # 生成提示词
        system_prompt, user_prompt = generate_translation_prompt(
            'batch', video_info, manager, context, 0
        )
        
        user_prompt = f"""请翻译以下视频字幕片段：

{context_summary}

请确保：
1. 术语一致性
2. 上下文连贯性
3. 语音时长适配

请输出完整的JSON格式翻译结果。"""
        
        success = False
        max_retries = 2
        
        for retry in range(max_retries):
            try:
                logger.debug(f"🔄 批次翻译尝试 {retry+1}/{max_retries}")
                
                response = client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_prompt}
                    ],
                    max_tokens=batch_size * 200,
                    timeout=120,
                    temperature=0.1
                )
                
                raw_output = response.choices[0].message.content.strip()
                
                # 尝试解析JSON
                json_success, translations, error_msg = parse_translation_json(raw_output)
                
                if json_success:
                    # JSON解析成功，但需要进一步处理
                    try:
                        data = json.loads(raw_output)
                        if 'translations' in data:
                            translations = data['translations']
                            
                            # 映射翻译结果
                            for i, item in enumerate(batch_items):
                                if i < len(translations):
                                    trans_item = translations[i]
                                    if isinstance(trans_item, dict) and 'translation' in trans_item:
                                        full_idx = item['full_index']
                                        translation_text = trans_item['translation'].strip()
                                        full_translation[full_idx] = translation_text
                                        success_flags[full_idx] = bool(translation_text)
                            
                            success = True
                            logger.info(f"✅ 批次 {batch_idx+1} JSON解析成功")
                            break
                    except:
                        pass
                
                # 如果JSON解析失败，尝试回退模式
                if retry == max_retries - 1:
                    logger.warning(f"⚠️ 批次 {batch_idx+1} 解析失败，回退到逐句翻译")
                    for idx in target_indices:
                        text = transcript[idx].get('text', '').strip()
                        duration = float(transcript[idx].get('end', 0)) - float(transcript[idx].get('start', 0))
                        translation = translate_single_sentence(text, duration, video_info, manager)
                        full_translation[idx] = translation
                        success_flags[idx] = translation != text
                    success = True
                    
            except Exception as e:
                logger.error(f"❌ 批次翻译失败 (尝试 {retry+1}): {e}")
                if retry < max_retries - 1:
                    time.sleep(2)
        
        if batch_idx < total_batches - 1:
            time.sleep(1 if MODEL_TYPE == ModelType.OLLAMA else 0.5)
    
    return full_translation, success_flags

# === 主翻译函数 ===
def _translate(
    video_info: dict,
    transcript: List[Dict],
    target_language: str = '简体中文'
) -> Tuple[List[str], List[bool]]:
    """主翻译函数"""
    
    # 初始化翻译管理器
    manager = TranslationManager()
    manager.update_from_video_info(video_info)
    
    # 选择翻译模式
    if TRANSLATION_MODE == 'batch' and len(transcript) >= 10:
        logger.info("🚀 使用批次翻译模式")
        return translate_in_batches(
            transcript, video_info, manager,
            batch_size=BATCH_SIZE,
            overlap=min(CONTEXT_WINDOW_SIZE, 2)
        )
    elif TRANSLATION_MODE == 'sliding':
        logger.info("🚀 使用滑动窗口上下文翻译模式")
        return translate_with_context_window(
            transcript, video_info, manager,
            window_size=CONTEXT_WINDOW_SIZE
        )
    else:
        logger.info("🚀 使用逐句翻译模式")
        # 逐句翻译
        full_translation = []
        success_flags = []
        
        for idx, line in enumerate(transcript):
            text = line.get('text', '').strip()
            if not text:
                full_translation.append("")
                success_flags.append(False)
                continue
            
            duration = float(line.get('end', 0)) - float(line.get('start', 0))
            translation = translate_single_sentence(text, duration, video_info, manager)
            
            full_translation.append(translation)
            success_flags.append(translation != text)
            
            progress = (idx + 1) / len(transcript) * 100
            if idx % 10 == 0 or idx == len(transcript) - 1:
                logger.info(f"📈 进度: {idx+1}/{len(transcript)} ({progress:.1f}%)")
        
        return full_translation, success_flags

# === 辅助函数 ===
def ensure_transcript_length(transcript: str, max_length: int = 1500) -> str:
    if len(transcript) <= max_length:
        return transcript
    mid = len(transcript) // 2
    half = max_length // 2
    start = max(0, mid - half)
    end = min(len(transcript), mid + half)
    return transcript[start:end]

def safe_json_parse(text: str) -> dict:
    if not text:
        return {"title": "", "summary": ""}
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        json_patterns = [
            r'```json\s*(.*?)\s*```',
            r'```\s*(.*?)\s*```',
            r'\{.*\}',
        ]
        for pattern in json_patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                json_text = match.group(1) if len(match.groups()) > 0 else match.group(0)
                try:
                    return json.loads(json_text.strip())
                except:
                    continue
        title_match = re.search(r'"title"\s*:\s*"([^"]+)"', text)
        summary_match = re.search(r'"summary"\s*:\s*"([^"]+)"', text, re.DOTALL)
        if title_match and summary_match:
            return {"title": title_match.group(1), "summary": summary_match.group(1)}
        if '"title"' in text and '"summary"' in text:
            lines = text.split('\n')
            title = ""
            summary = ""
            for line in lines:
                if '"title"' in line.lower():
                    title = line.split(':', 1)[-1].strip().strip('",')
                elif '"summary"' in line.lower():
                    summary = line.split(':', 1)[-1].strip().strip('",')
            if title or summary:
                return {"title": title, "summary": summary}
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        if len(lines) >= 2:
            return {"title": lines[0], "summary": lines[1]}
        elif len(lines) == 1:
            return {"title": lines[0], "summary": lines[0]}
        return {"title": "", "summary": "无法解析内容"}

def get_model_params():
    return {
        'temperature': 0.3,
        'top_p': 0.9,
        'frequency_penalty': 0.0,
        'presence_penalty': 0.0,
    }

def summarize_with_retry(
    info: dict,
    transcript: list,
    target_language: str = '简体中文',
    max_retries: int = 3
) -> dict:
    transcript_text = ' '.join(line['text'] for line in transcript)
    transcript_text = ensure_transcript_length(transcript_text, max_length=1000)
    logger.info(f"📝 准备总结，字幕长度: {len(transcript_text)} 字符")
    
    title = info.get('title', '未知标题')
    
    prompt = f"""请为以下视频内容生成详细总结：

视频标题: "{title}"

视频内容片段:
{transcript_text[:800]}...

请输出标准的JSON格式：
{{
  "title": "简洁的标题",
  "summary": "详细的内容摘要，涵盖视频的主要观点和信息"
}}

要求：
1. 用{target_language}回复
2. 确保summary包含视频的核心内容和关键信息"""

    if MODEL_TYPE == ModelType.OLLAMA:
        system_prompt = "你是一位专业的视频内容分析师。请提供准确的总结。"
    else:
        system_prompt = f"你是一位专业的视频内容分析师。请提供详细准确的总结，用{target_language}回复。"
    
    client = get_client()
    model_params = get_model_params()
    
    for attempt in range(max_retries):
        try:
            logger.info(f"🔄 尝试生成总结 (第{attempt+1}次)...")
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
                timeout=60,
                **model_params
            )
            summary_text = response.choices[0].message.content
            logger.debug(f"📄 原始总结输出: {summary_text[:200]}...")
            summary_data = safe_json_parse(summary_text)
            title_out = summary_data.get('title', '').strip()
            summary = summary_data.get('summary', '').strip()
            if not title_out or title_out == "无法解析内容":
                title_out = info.get('title', '')
            if not summary or summary == "无法解析内容":
                summary = "未能生成详细摘要"
            logger.info(f"✅ 总结生成成功: {title_out[:50]}...")
            result = {
                'title': title_out,
                'author': info.get('uploader', ''),
                'summary': summary,
                'tags': info.get('tags', []),
                'language': target_language,
                'model_type': MODEL_TYPE.value
            }
            return result
        except Exception as e:
            logger.warning(f"⚠️ 总结失败 (第{attempt+1}次): {e}")
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt
                logger.info(f"⏳ 等待 {wait_time} 秒后重试...")
                time.sleep(wait_time)
    logger.error("❌ 所有总结尝试失败，使用默认值")
    return {
        'title': info.get('title', ''),
        'author': info.get('uploader', ''),
        'summary': "视频内容摘要生成失败",
        'tags': info.get('tags', []),
        'language': target_language,
        'model_type': MODEL_TYPE.value
    }

def split_text_into_sentences(para: str) -> List[str]:
    if not para:
        return []
    sentences = re.split(r'(?<=[。！？?!\.])\s+', para)
    cleaned = [s.strip() for s in sentences if s.strip()]
    if not cleaned:
        return [para.strip()]
    return cleaned

def split_sentences_fixed(translation: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    output_data = []
    for item in translation:
        try:
            original_start = float(item.get('start', 0))
            original_end = float(item.get('end', 0))
            text = item.get('text', '')
            speaker = item.get('speaker', '')
            translation_text = item.get('translation', '').strip()
            if not translation_text:
                continue
            sentences = split_text_into_sentences(translation_text)
            if not sentences:
                output_data.append({
                    "start": round(original_start, 3),
                    "end": round(original_end, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": translation_text
                })
                continue
            if len(sentences) == 1:
                output_data.append({
                    "start": round(original_start, 3),
                    "end": round(original_end, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": sentences[0]
                })
                continue
            total_sentences = len(sentences)
            original_duration = original_end - original_start
            if original_duration <= 0:
                duration_per_sentence = 1.0 / total_sentences
            else:
                duration_per_sentence = original_duration / total_sentences
            current_time = original_start
            for i, sentence in enumerate(sentences):
                if not sentence:
                    continue
                if i == total_sentences - 1:
                    end_time = original_end
                else:
                    end_time = current_time + duration_per_sentence
                end_time = min(end_time, original_end)
                if end_time <= current_time:
                    end_time = current_time + 0.01
                output_data.append({
                    "start": round(current_time, 3),
                    "end": round(end_time, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": sentence
                })
                current_time = end_time
        except Exception as e:
            logger.error(f"❌ 句子拆分出错: {e}")
            if 'translation_text' in locals() and translation_text:
                output_data.append({
                    "start": round(original_start, 3),
                    "end": round(original_end, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": translation_text
                })
    return output_data

def fix_timestamps(original_transcript: List[Dict[str, Any]], 
                  translated_transcript: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if len(original_transcript) == 0:
        return translated_transcript
    original_map = {}
    for orig in original_transcript:
        key = f"{orig.get('text', '')}_{orig.get('speaker', '')}"
        original_map[key] = {
            "start": round(float(orig.get('start', 0)), 3),
            "end": round(float(orig.get('end', 0)), 3)
        }
    fixed = []
    for trans in translated_transcript:
        text = trans.get('text', '')
        speaker = trans.get('speaker', '')
        key = f"{text}_{speaker}"
        if key in original_map:
            start = original_map[key]["start"]
            end = original_map[key]["end"]
        else:
            start = round(float(trans.get('start', 0)), 3)
            end = round(float(trans.get('end', 0)), 3)
        fixed_item = {
            "start": start,
            "end": end,
            "text": text,
            "speaker": speaker,
            "translation": trans.get('translation', text)
        }
        fixed.append(fixed_item)
    return fixed

def validate_time_alignment(original: List[Dict[str, Any]], 
                          translated: List[Dict[str, Any]]) -> bool:
    if len(original) != len(translated):
        logger.warning(f"❌ 条目数量不匹配: 原始 {len(original)} vs 翻译 {len(translated)}")
        return False
    all_match = True
    for i, (orig, trans) in enumerate(zip(original, translated)):
        orig_start = round(float(orig.get('start', 0)), 3)
        orig_end = round(float(orig.get('end', 0)), 3)
        trans_start = round(float(trans.get('start', 0)), 3)
        trans_end = round(float(trans.get('end', 0)), 3)
        if (abs(orig_start - trans_start) > 0.001 or 
            abs(orig_end - trans_end) > 0.001):
            logger.warning(f"⚠️ 第 {i+1} 条时间戳不匹配:")
            logger.warning(f"    原始: {orig_start} - {orig_end} (时长: {orig_end - orig_start:.3f}s)")
            logger.warning(f"    翻译: {trans_start} - {trans_end} (时长: {trans_end - trans_start:.3f}s)")
            all_match = False
    if all_match:
        logger.info("✅ 时间戳验证通过 - 所有时间戳完全一致")
    else:
        logger.warning("⚠️ 时间戳验证失败 - 部分时间戳不匹配")
    return all_match

# === 主处理函数 ===
def translate(folder: str, target_language: str = '简体中文') -> bool:
    try:
        translation_path = os.path.join(folder, 'translation.json')
        if os.path.exists(translation_path):
            logger.info(f"📂 已存在翻译，跳过: {folder}")
            return True
        
        info_path = os.path.join(folder, 'download.info.json')
        transcript_path = os.path.join(folder, 'transcript.json')
        if not os.path.exists(info_path) or not os.path.exists(transcript_path):
            logger.error(f"❌ 缺少必要文件")
            return False
        
        # 加载原始数据
        with open(info_path, 'r', encoding='utf-8') as f:
            raw_info = json.load(f)
        
        # 获取增强的视频信息
        video_info = get_enhanced_info(raw_info)
        
        with open(transcript_path, 'r', encoding='utf-8') as f:
            original_transcript = json.load(f)
        
        logger.info(f"📄 加载了 {len(original_transcript)} 条原始字幕")
        logger.info(f"🎬 视频标题: {video_info.get('title', '未知')}")
        logger.info(f"🏷️  视频领域: {video_info.get('domain', 'general')}")
        
        # 生成或加载摘要
        summary_path = os.path.join(folder, 'summary.json')
        if os.path.exists(summary_path):
            try:
                with open(summary_path, 'r', encoding='utf-8') as f:
                    summary = json.load(f)
                logger.info("📥 加载现有摘要")
            except Exception as e:
                logger.warning(f"⚠️ 加载摘要失败，重新生成: {e}")
                summary = summarize_with_retry(video_info, original_transcript, target_language)
                with open(summary_path, 'w', encoding='utf-8') as f:
                    json.dump(summary, f, indent=2, ensure_ascii=False)
        else:
            logger.info("🔄 生成新摘要")
            summary = summarize_with_retry(video_info, original_transcript, target_language)
            with open(summary_path, 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)
        
        # 开始翻译
        logger.info("🚀 开始翻译字幕...")
        translations, success_flags = _translate(video_info, original_transcript, target_language)
        
        # 构建结果
        working_transcript = []
        for i, line in enumerate(original_transcript):
            translation_text = translations[i] if i < len(translations) else line.get('text', '')
            working_line = {
                "start": float(line.get('start', 0)),
                "end": float(line.get('end', 0)),
                "text": line.get('text', ''),
                "speaker": line.get('speaker', ''),
                "translation": translation_text
            }
            working_transcript.append(working_line)
        
        if SPLIT_SENTENCES:
            logger.info("🔧 拆分长句...")
            final_transcript = split_sentences_fixed(working_transcript)
        else:
            logger.info("📝 保持句子原样，不拆分...")
            final_transcript = working_transcript
        
        logger.info("🔍 强制修正时间戳以确保与原始一致...")
        final_transcript = fix_timestamps(original_transcript, final_transcript)
        
        logger.info("✅ 验证时间戳一致性...")
        validate_time_alignment(original_transcript, final_transcript)
        
        for item in final_transcript:
            item["start"] = round(float(item.get("start", 0)), 3)
            item["end"] = round(float(item.get("end", 0)), 3)
        
        # 保存翻译结果
        with open(translation_path, 'w', encoding='utf-8') as f:
            json.dump(final_transcript, f, indent=2, ensure_ascii=False)
        
        logger.info(f"✅ 翻译完成: {translation_path}")
        
        # 统计信息
        total = len(success_flags)
        success_count = sum(success_flags)
        failure_count = total - success_count
        
        logger.info(f"\n{'='*60}")
        logger.info(f"📊 翻译结果统计:")
        logger.info(f"  总计: {total} 句")
        logger.info(f"  成功: {success_count} 句 ({success_count/total*100:.1f}%)")
        logger.info(f"  失败: {failure_count} 句 ({failure_count/total*100:.1f}%)")
        
        if failure_count > 0:
            logger.warning(f"\n⚠️  以下句子翻译失败（回退到原文）:")
            for i, (line, success) in enumerate(zip(original_transcript, success_flags)):
                if not success:
                    text = line.get('text', '')[:100]
                    start = line.get('start', 0)
                    end = line.get('end', 0)
                    logger.warning(f"  [{i+1}] {start:.1f}s-{end:.1f}s: {text}...")
        
        # 保存详细统计
        stats_path = os.path.join(folder, 'translation_stats.json')
        stats = {
            'total_lines': total,
            'success_count': success_count,
            'failure_count': failure_count,
            'success_rate': round(success_count / total * 100, 2) if total > 0 else 0,
            'translation_mode': TRANSLATION_MODE,
            'context_window': CONTEXT_WINDOW_SIZE if TRANSLATION_MODE == 'sliding' else None,
            'batch_size': BATCH_SIZE if TRANSLATION_MODE == 'batch' else None,
            'video_info': {
                'title': video_info.get('title', ''),
                'domain': video_info.get('domain', ''),
                'duration': video_info.get('duration', 0)
            },
            'failed_lines': [
                {
                    'index': i,
                    'start': line.get('start'),
                    'end': line.get('end'),
                    'text': line.get('text', '')[:200]
                }
                for i, (line, success) in enumerate(zip(original_transcript, success_flags))
                if not success
            ]
        }
        
        with open(stats_path, 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)
        
        logger.info(f"📊 统计已保存: {stats_path}")
        return True
        
    except Exception as e:
        logger.error(f"❌ 翻译失败: {e}")
        logger.error(traceback.format_exc())
        return False

def translate_all_transcript_under_folder(root_folder: str, target_language: str = '简体中文') -> int:
    logger.info("🔍 检查模型服务...")
    if not check_model_health():
        logger.error("❌ 模型服务不可用")
        return 0
    
    count = 0
    failed = 0
    video_folders = []
    
    logger.info(f"📂 扫描目录: {root_folder}")
    for root, dirs, files in os.walk(root_folder):
        if 'transcript.json' in files and 'translation.json' not in files:
            video_folders.append(root)
    
    logger.info(f"🎯 找到 {len(video_folders)} 个需要翻译的视频")
    if not video_folders:
        logger.info("✅ 所有视频都已翻译完成")
        return 0
    
    for i, folder in enumerate(video_folders):
        logger.info(f"\n{'='*60}")
        logger.info(f"🎬 处理视频 ({i+1}/{len(video_folders)}):")
        logger.info(f"📁 目录: {folder}")
        
        try:
            start_time = time.time()
            if translate(folder, target_language):
                count += 1
                elapsed = time.time() - start_time
                logger.info(f"✅ 完成 ({elapsed:.1f}秒)")
            else:
                failed += 1
                logger.error(f"❌ 失败")
        except Exception as e:
            failed += 1
            logger.error(f"❌ 处理异常: {e}")
            logger.error(traceback.format_exc())
        
        if i < len(video_folders) - 1:
            wait_time = 1
            logger.info(f"⏳ 等待 {wait_time} 秒处理下一个...")
            time.sleep(wait_time)
    
    logger.info(f"\n{'='*60}")
    logger.info(f"🏁 翻译完成")
    logger.info(f"📈 总计: {len(video_folders)} 个视频")
    logger.info(f"✅ 成功: {count} 个")
    logger.info(f"❌ 失败: {failed} 个")
    
    return count

# === 主程序 ===
if __name__ == '__main__':
    logger.remove()
    logger.add(
        sys.stderr,
        level="INFO",
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{message}</cyan>",
        colorize=True
    )
    logger.add(
        "translation.log",
        level="DEBUG",
        rotation="10 MB",
        retention="7 days",
        encoding="utf-8",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}"
    )
    
    print("\n" + "="*60)
    print("🎬 视频字幕翻译工具 - 优化版")
    print("="*60)
    logger.info(f"📦 模型类型: {MODEL_TYPE.value}")
    logger.info(f"🤖 模型名称: {MODEL_NAME}")
    logger.info(f"🌐 API地址: {API_BASE}")
    logger.info(f"🎯 翻译模式: {TRANSLATION_MODE}")
    logger.info(f"🔧 目标语言: {TARGET_LANGUAGE}")
    
    if TRANSLATION_MODE == 'sliding':
        logger.info(f"🔍 上下文窗口: {CONTEXT_WINDOW_SIZE} 句")
    elif TRANSLATION_MODE == 'batch':
        logger.info(f"📦 批次大小: {BATCH_SIZE} 句")
    
    logger.info("🧪 测试连接中...")
    try:
        import requests
        test_url = API_BASE.replace('/v1', '/api/tags') if '/v1' in API_BASE else f"{API_BASE}/api/tags"
        response = requests.get(test_url, timeout=10)
        if response.status_code == 200:
            models = response.json().get('models', [])
            model_names = [m['name'] for m in models]
            logger.info(f"✅ 连接成功! 可用模型: {', '.join(model_names)}")
        else:
            logger.warning(f"⚠️ 连接测试状态码: {response.status_code}")
    except Exception as e:
        logger.warning(f"⚠️ 连接测试异常: {e}")
    
    print("="*60 + "\n")
    
    success_count = translate_all_transcript_under_folder(
        r'videos',
        TARGET_LANGUAGE
    )
    
    if success_count > 0:
        logger.info(f"🎉 成功翻译 {success_count} 个视频")
    else:
        logger.info("ℹ️  没有需要翻译的视频或翻译失败")