# -*- coding: utf-8 -*-
"""
视频字幕翻译工具 - VAD 时长感知版
支持：OpenAI API, LM Studio, Ollama
修复：确保翻译后时间戳与原始完全一致
增强：使用 Silero VAD 校准的 vad_duration 实现长度感知翻译
"""

import json
import os
import re
import sys
import time
import traceback
import socket
from enum import Enum
from typing import Optional, List, Dict, Any
from openai import OpenAI
from dotenv import load_dotenv
from loguru import logger

# 加载环境变量
load_dotenv()

# === 配置模型类型 ===
class ModelType(Enum):
    OPENAI = "openai"
    LM_STUDIO = "lm_studio"
    OLLAMA = "ollama"

# 从环境变量获取配置
MODEL_NAME = os.getenv('MODEL_NAME', 'qwen3:8b').strip()
API_BASE = os.getenv('OPENAI_API_BASE', '').strip()
API_KEY = os.getenv('OPENAI_API_KEY', '').strip()

# 自动检测模型类型
def detect_model_type() -> ModelType:
    """自动检测模型类型"""
    api_base_lower = API_BASE.lower()
    
    if not API_BASE:
        logger.info("未设置API_BASE，默认使用Ollama")
        return ModelType.OLLAMA
    
    if 'localhost' in api_base_lower or '127.0.0.1' in api_base_lower or '::1' in api_base_lower:
        if 'lm-studio' in api_base_lower or 'lmstudio' in api_base_lower or ':1234' in API_BASE:
            return ModelType.LM_STUDIO
        elif 'ollama' in api_base_lower or ':11434' in API_BASE:
            return ModelType.OLLAMA
        else:
            return ModelType.OLLAMA
    else:
        return ModelType.OPENAI

MODEL_TYPE = detect_model_type()

# === Ollama特定配置 ===
if MODEL_TYPE == ModelType.OLLAMA:
    if not API_BASE:
        API_BASE = 'http://127.0.0.1:11434/v1'
    if not API_KEY:
        API_KEY = 'ollama'
    logger.info(f"✅ 使用Ollama模型: {MODEL_NAME}")
    if 'localhost' in API_BASE.lower():
        API_BASE = API_BASE.replace('localhost', '127.0.0.1')
elif MODEL_TYPE == ModelType.LM_STUDIO:
    logger.info(f"📦 使用LM Studio模型: {MODEL_NAME}")
elif MODEL_TYPE == ModelType.OPENAI:
    logger.info(f"☁️  使用OpenAI兼容API模型: {MODEL_NAME}")

logger.info(f"🌐 API地址: {API_BASE}")

# === 配置选项 ===
SPLIT_SENTENCES = False  # 保持时间戳一致，禁用拆分

# === 创建全局客户端 ===
def create_openai_client() -> OpenAI:
    if MODEL_TYPE == ModelType.OLLAMA:
        return OpenAI(
            base_url=API_BASE,
            api_key=API_KEY,
            timeout=180.0,
            max_retries=3
        )
    return OpenAI(
        base_url=API_BASE,
        api_key=API_KEY,
        timeout=120.0
    )

_client: Optional[OpenAI] = None

def get_client() -> OpenAI:
    global _client
    if _client is None:
        _client = create_openai_client()
    return _client

# === 健康检查 ===
def check_model_health() -> bool:
    try:
        port = 11434
        match = re.search(r':(\d+)', API_BASE)
        if match:
            port = int(match.group(1))
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        result = sock.connect_ex(('127.0.0.1', port))
        sock.close()
        if result != 0:
            logger.error(f"❌ 端口 {port} 未开放")
            return False
        logger.info(f"✅ 端口 {port} 开放")
    except Exception as e:
        logger.error(f"❌ 端口检查失败: {e}")
        return False

    max_retries = 3
    for attempt in range(max_retries):
        try:
            logger.info(f"🧪 健康检查尝试 {attempt + 1}/{max_retries}")
            import requests
            if MODEL_TYPE == ModelType.OLLAMA:
                test_url = API_BASE.replace('/v1', '/api/tags')
                response = requests.get(test_url, timeout=10)
                if response.status_code == 200:
                    logger.info("✅ Ollama API 测试成功")
                    return True
                else:
                    logger.warning(f"API测试状态码: {response.status_code}")
            else:
                test_client = create_openai_client()
                response = test_client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=[{"role": "user", "content": "ping"}],
                    max_tokens=5,
                    timeout=15
                )
                if response.choices[0].message.content:
                    logger.info(f"✅ 模型健康检查成功")
                    return True
        except Exception as e:
            logger.warning(f"⚠️ 健康检查异常 (尝试 {attempt + 1}): {e}")
        if attempt < max_retries - 1:
            wait_time = 2 * (attempt + 1)
            logger.info(f"⏳ 等待 {wait_time} 秒后重试...")
            time.sleep(wait_time)
    logger.error("❌ 所有健康检查尝试失败")
    return False

def get_necessary_info(info: dict) -> dict:
    return {
        'title': info.get('title', ''),
        'uploader': info.get('uploader', ''),
        'description': info.get('description', ''),
        'upload_date': info.get('upload_date', ''),
        'categories': info.get('categories', []),
        'tags': info.get('tags', []),
    }

def ensure_transcript_length(transcript: str, max_length: int = 1500) -> str:
    if len(transcript) <= max_length:
        return transcript
    mid = len(transcript) // 2
    half = max_length // 2
    start = max(0, mid - half)
    end = min(len(transcript), mid + half)
    return transcript[start:end]

def safe_json_parse(text: str) -> dict:
    if not text:
        return {"title": "", "summary": ""}
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        json_patterns = [
            r'```json\s*(.*?)\s*```',
            r'```\s*(.*?)\s*```',
            r'\{.*\}',
        ]
        for pattern in json_patterns:
            match = re.search(pattern, text, re.DOTALL)
            if match:
                json_text = match.group(1) if len(match.groups()) > 0 else match.group(0)
                try:
                    return json.loads(json_text.strip())
                except:
                    continue
        title_match = re.search(r'"title"\s*:\s*"([^"]+)"', text)
        summary_match = re.search(r'"summary"\s*:\s*"([^"]+)"', text, re.DOTALL)
        if title_match and summary_match:
            return {"title": title_match.group(1), "summary": summary_match.group(1)}
        if '"title"' in text and '"summary"' in text:
            lines = text.split('\n')
            title = ""
            summary = ""
            for line in lines:
                if '"title"' in line.lower():
                    title = line.split(':', 1)[-1].strip().strip('",')
                elif '"summary"' in line.lower():
                    summary = line.split(':', 1)[-1].strip().strip('",')
            if title or summary:
                return {"title": title, "summary": summary}
        lines = [line.strip() for line in text.split('\n') if line.strip()]
        if len(lines) >= 2:
            return {"title": lines[0], "summary": lines[1]}
        elif len(lines) == 1:
            return {"title": lines[0], "summary": lines[0]}
        return {"title": "", "summary": "无法解析内容"}

def get_model_params():
    return {
        'temperature': 0.3,
        'top_p': 0.9,
        'frequency_penalty': 0.0,
        'presence_penalty': 0.0,
    }

def summarize_with_retry(
    info: dict,
    transcript: list,
    target_language: str = '简体中文',
    max_retries: int = 3
) -> dict:
    # 准备字幕文本
    transcript_text = ' '.join(line['text'] for line in transcript)
    transcript_text = ensure_transcript_length(transcript_text, max_length=1000)
    logger.info(f"📝 准备总结，字幕长度: {len(transcript_text)} 字符")
    
    # 提取标题
    title = info.get('title', '未知标题')
    
    # 统一构造 prompt（关键修复：确保所有分支都有 prompt）
    prompt = f"""请为以下视频内容生成详细总结：

视频标题: "{title}"

视频内容片段:
{transcript_text[:800]}...

请输出标准的JSON格式：
{{
  "title": "简洁的标题",
  "summary": "详细的内容摘要，涵盖视频的主要观点和信息"
}}

要求：
1. 用{target_language}回复
2. 确保summary包含视频的核心内容和关键信息"""

    # 系统提示（可微调）
    if MODEL_TYPE == ModelType.OLLAMA:
        system_prompt = "你是一位专业的视频内容分析师。请提供准确的总结。"
    else:
        system_prompt = f"你是一位专业的视频内容分析师。请提供详细准确的总结，用{target_language}回复。"
    
    client = get_client()
    model_params = get_model_params()
    
    for attempt in range(max_retries):
        try:
            logger.info(f"🔄 尝试生成总结 (第{attempt+1}次)...")
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500,
                timeout=60,
                **model_params
            )
            summary_text = response.choices[0].message.content
            logger.debug(f"📄 原始总结输出: {summary_text[:200]}...")
            summary_data = safe_json_parse(summary_text)
            title_out = summary_data.get('title', '').strip()
            summary = summary_data.get('summary', '').strip()
            if not title_out or title_out == "无法解析内容":
                title_out = info.get('title', '')
            if not summary or summary == "无法解析内容":
                summary = "未能生成详细摘要"
            logger.info(f"✅ 总结生成成功: {title_out[:50]}...")
            result = {
                'title': title_out,
                'author': info.get('uploader', ''),
                'summary': summary,
                'tags': info.get('tags', []),
                'language': target_language,
                'model_type': MODEL_TYPE.value
            }
            return result
        except Exception as e:
            logger.warning(f"⚠️ 总结失败 (第{attempt+1}次): {e}")
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt
                logger.info(f"⏳ 等待 {wait_time} 秒后重试...")
                time.sleep(wait_time)
    logger.error("❌ 所有总结尝试失败，使用默认值")
    return {
        'title': info.get('title', ''),
        'author': info.get('uploader', ''),
        'summary': "视频内容摘要生成失败",
        'tags': info.get('tags', []),
        'language': target_language,
        'model_type': MODEL_TYPE.value
    }

def translation_postprocess(result: str) -> str:
    if not result:
        return ""
    result = re.sub(r'\（[^)]*\）', '', result)
    result = re.sub(r'\([^)]*\)', '', result)
    result = result.replace('...', '，')
    result = result.replace('..', '，')
    result = re.sub(r'(?<=\d),(?=\d)', '', result)
    replacements = {
        '²': '的平方',
        '————': '：',
        '——': '：',
        '°': '度',
        'AI': '人工智能',
        'transformer': 'Transformer',
        'Transformer': 'Transformer',
        'GPT': 'GPT',
        'LLM': '大语言模型',
        '\u200b': '',
        '\ufeff': '',
    }
    for old, new in replacements.items():
        result = result.replace(old, new)
    result = re.sub(r'\s+', ' ', result).strip()
    return result

def safe_string_access(text: str, start: int, end: int) -> str:
    if not text:
        return ""
    start = max(0, min(start, len(text)))
    end = max(0, min(end, len(text)))
    if start >= end:
        return ""
    return text[start:end]

def valid_translation(text: str, translation: str) -> tuple:
    if not translation:
        return False, "翻译结果为空"
    cleaned_translation = translation.strip()
    prefixes = [
        '翻译：', '翻译:', '译文：', '译文:', 
        '输出：', '输出:', '结果：', '结果:',
        '响应：', '响应:', '回答：', '回答:',
        'assistant:', 'Assistant:',
    ]
    suffixes = ['。', '」', '"', "'", '》', '”', '」', '》', '>']
    for prefix in prefixes:
        if cleaned_translation.startswith(prefix):
            cleaned_translation = cleaned_translation[len(prefix):].strip()
    for suffix in suffixes:
        if cleaned_translation.endswith(suffix):
            cleaned_translation = cleaned_translation[:-len(suffix)].strip()
    if cleaned_translation.startswith('```') and cleaned_translation.endswith('```'):
        cleaned_translation = safe_string_access(cleaned_translation, 3, -3).strip()
    quotes_pairs = [
        ('"', '"'), ("'", "'"), 
        ('《', '》'), ('「', '」'), 
    ]
    for start_char, end_char in quotes_pairs:
        if (cleaned_translation.startswith(start_char) and 
            cleaned_translation.endswith(end_char) and
            len(cleaned_translation) >= len(start_char) + len(end_char)):
            cleaned_translation = safe_string_access(
                cleaned_translation, 
                len(start_char), 
                -len(end_char)
            ).strip()
    patterns = [
        r'^.*?翻译[：:]\s*',
        r'^.*?[：:]\s*',
        r'^"?\s*',
        r'^\s*',
        r'^[\"\']',
        r'[\"\']$'
    ]
    for pattern in patterns:
        cleaned_translation = re.sub(pattern, '', cleaned_translation, count=1)
    cleaned_translation = translation_postprocess(cleaned_translation)
    if not cleaned_translation:
        return False, "处理后翻译为空"
    max_length_multiplier = 3.0 if MODEL_TYPE == ModelType.OLLAMA else 2.0
    if len(text) <= 10 and len(cleaned_translation) > 50:
        logger.warning(f"短文本翻译过长: {len(cleaned_translation)} > 50")
    if len(cleaned_translation) > len(text) * max_length_multiplier:
        return False, f"翻译过长: {len(cleaned_translation)} > {len(text)} * {max_length_multiplier}"
    forbidden = ['翻译结果', '原文内容', '简体中文', '中文翻译', 
                'translate', 'Translate', '```json', 'JSON格式']
    if MODEL_TYPE != ModelType.OLLAMA:
        forbidden.extend(['assistant', 'system', 'user'])
    for word in forbidden:
        if word.lower() in cleaned_translation.lower():
            return False, f"包含禁止词: {word}"
    if re.search(r'[\u4e00-\u9fff]', cleaned_translation):
        return True, cleaned_translation
    elif cleaned_translation and len(cleaned_translation) > 0:
        return True, cleaned_translation
    else:
        return False, "翻译内容无效"

def split_text_into_sentences(para: str) -> List[str]:
    if not para:
        return []
    sentences = re.split(r'(?<=[。！？?!\.])\s+', para)
    cleaned = [s.strip() for s in sentences if s.strip()]
    if not cleaned:
        return [para.strip()]
    return cleaned

def split_sentences_fixed(translation: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    output_data = []
    for item in translation:
        try:
            original_start = float(item.get('start', 0))
            original_end = float(item.get('end', 0))
            text = item.get('text', '')
            speaker = item.get('speaker', '')
            translation_text = item.get('translation', '').strip()
            if not translation_text:
                continue
            sentences = split_text_into_sentences(translation_text)
            if not sentences:
                output_data.append({
                    "start": round(original_start, 3),
                    "end": round(original_end, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": translation_text
                })
                continue
            if len(sentences) == 1:
                output_data.append({
                    "start": round(original_start, 3),
                    "end": round(original_end, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": sentences[0]
                })
                continue
            total_sentences = len(sentences)
            original_duration = original_end - original_start
            if original_duration <= 0:
                duration_per_sentence = 1.0 / total_sentences
            else:
                duration_per_sentence = original_duration / total_sentences
            current_time = original_start
            for i, sentence in enumerate(sentences):
                if not sentence:
                    continue
                if i == total_sentences - 1:
                    end_time = original_end
                else:
                    end_time = current_time + duration_per_sentence
                end_time = min(end_time, original_end)
                if end_time <= current_time:
                    end_time = current_time + 0.01
                output_data.append({
                    "start": round(current_time, 3),
                    "end": round(end_time, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": sentence
                })
                current_time = end_time
        except Exception as e:
            logger.error(f"❌ 句子拆分出错: {e}")
            if 'translation_text' in locals() and translation_text:
                output_data.append({
                    "start": round(original_start, 3),
                    "end": round(original_end, 3),
                    "text": text,
                    "speaker": speaker,
                    "translation": translation_text
                })
    return output_data

def fix_timestamps(original_transcript: List[Dict[str, Any]], 
                  translated_transcript: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if len(original_transcript) == 0:
        return translated_transcript
    original_map = {}
    for orig in original_transcript:
        key = f"{orig.get('text', '')}_{orig.get('speaker', '')}"
        original_map[key] = {
            "start": round(float(orig.get('start', 0)), 3),
            "end": round(float(orig.get('end', 0)), 3)
        }
    fixed = []
    for trans in translated_transcript:
        text = trans.get('text', '')
        speaker = trans.get('speaker', '')
        key = f"{text}_{speaker}"
        if key in original_map:
            start = original_map[key]["start"]
            end = original_map[key]["end"]
        else:
            start = round(float(trans.get('start', 0)), 3)
            end = round(float(trans.get('end', 0)), 3)
        fixed_item = {
            "start": start,
            "end": end,
            "text": text,
            "speaker": speaker,
            "translation": trans.get('translation', text)
        }
        fixed.append(fixed_item)
    return fixed

def validate_time_alignment(original: List[Dict[str, Any]], 
                          translated: List[Dict[str, Any]]) -> bool:
    if len(original) != len(translated):
        logger.warning(f"❌ 条目数量不匹配: 原始 {len(original)} vs 翻译 {len(translated)}")
        return False
    all_match = True
    for i, (orig, trans) in enumerate(zip(original, translated)):
        orig_start = round(float(orig.get('start', 0)), 3)
        orig_end = round(float(orig.get('end', 0)), 3)
        trans_start = round(float(trans.get('start', 0)), 3)
        trans_end = round(float(trans.get('end', 0)), 3)
        if (abs(orig_start - trans_start) > 0.001 or 
            abs(orig_end - trans_end) > 0.001):
            logger.warning(f"⚠️ 第 {i+1} 条时间戳不匹配:")
            logger.warning(f"    原始: {orig_start} - {orig_end} (时长: {orig_end - orig_start:.3f}s)")
            logger.warning(f"    翻译: {trans_start} - {trans_end} (时长: {trans_end - trans_start:.3f}s)")
            all_match = False
    if all_match:
        logger.info("✅ 时间戳验证通过 - 所有时间戳完全一致")
    else:
        logger.warning("⚠️ 时间戳验证失败 - 部分时间戳不匹配")
    return all_match

def _translate(summary: dict, transcript: list, target_language: str = '简体中文') -> tuple:
    client = get_client()
    model_params = get_model_params()
    translation_params = model_params.copy()
    translation_params['temperature'] = 0.2

    if MODEL_TYPE == ModelType.OLLAMA:
        system_prompt = f"""你是一位专业翻译，请将英文翻译成地道、流畅的{target_language}。

要求：
1. 只输出翻译结果，不要添加任何解释、前缀或后缀
2. 保持专业术语的准确性
3. 确保翻译自然流畅
4. 如果原文是专有名词或无需翻译，直接输出原文
5. 请根据“有效语音时长”控制译文长度（短语音用短句，长语音可稍详细）
"""
    else:
        system_prompt = f"""你是一位专业翻译，请将英文翻译成地道、流畅的{target_language}。

要求：
1. 保持专业性和准确性
2. 翻译要自然、流畅、地道
3. 只输出翻译结果，不要添加任何解释或注释
4. 专有名词保持原样
5. 请根据“有效语音时长”控制译文长度
"""

    full_translation = []
    success_flags = []
    history = []
    total_lines = len(transcript)
    logger.info(f"📊 开始翻译，共 {total_lines} 句")

    for idx, line in enumerate(transcript):
        text = line.get('text', '').strip()
        if not text:
            full_translation.append("")
            success_flags.append(False)
            continue

        original_duration = float(line.get('end', 0)) - float(line.get('start', 0))
        vad_duration = line.get('vad_duration')
        if vad_duration is not None:
            actual_duration = min(float(vad_duration), original_duration)
            duration_info = f"(VAD校准后: {actual_duration:.1f}s)"
        else:
            actual_duration = original_duration
            duration_info = f"(原始时长: {actual_duration:.1f}s)"

        progress = (idx + 1) / total_lines * 100
        logger.info(f"📈 进度: {idx+1}/{total_lines} ({progress:.1f}%) {duration_info} - {text[:80]}...")

        translated = None
        translation_success = False
        max_retries = 3

        for retry in range(max_retries):
            try:
                user_message = f'原文: "{text}"\n有效语音时长: {actual_duration:.1f}秒\n请翻译成{target_language}，控制译文长度以匹配此时间。'
                messages = [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message}
                ]
                if history and len(history) > 0:
                    recent_history = history[-2:] if len(history) > 2 else history
                    messages = [messages[0]] + recent_history + [messages[1]]
                response = client.chat.completions.create(
                    model=MODEL_NAME,
                    messages=messages,
                    max_tokens=len(text) * 4,
                    timeout=60,
                    **translation_params
                )
                raw_output = response.choices[0].message.content.strip()
                logger.debug(f"📥 原文: {text}")
                logger.debug(f"📤 原始输出: {raw_output}")
                success, clean_translation = valid_translation(text, raw_output)
                if success:
                    translated = clean_translation
                    translation_success = True
                    logger.info(f"✅ 译文 ({actual_duration:.1f}s): {clean_translation}")
                    history.append({"role": "user", "content": user_message})
                    history.append({"role": "assistant", "content": clean_translation})
                    if len(history) > 6:
                        history = history[-6:]
                    break
                else:
                    logger.warning(f"⚠️ 翻译验证失败 (第{retry+1}次): {clean_translation}")
                    if retry < max_retries - 1:
                        time.sleep(1)
                    else:
                        try:
                            simple_response = client.chat.completions.create(
                                model=MODEL_NAME,
                                messages=[{"role": "user", "content": f'只翻译这句英文: "{text}"'}],
                                max_tokens=100,
                                timeout=30,
                                **translation_params
                            )
                            simple_translation = simple_response.choices[0].message.content.strip()
                            success, clean_translation = valid_translation(text, simple_translation)
                            if success:
                                translated = clean_translation
                                translation_success = True
                                logger.info(f"✅ 译文 ({actual_duration:.1f}s): {clean_translation}")
                            else:
                                translated = text
                                logger.info(f"⚠️ 回退到原文: {text}")
                        except:
                            translated = text
                            logger.info(f"⚠️ 回退到原文: {text}")
            except Exception as e:
                logger.error(f"❌ 翻译请求失败 (第{retry+1}次): {e}")
                if retry < max_retries - 1:
                    wait_time = 2 ** retry
                    logger.info(f"⏳ 等待 {wait_time} 秒后重试...")
                    time.sleep(wait_time)
                else:
                    translated = text
                    logger.info(f"⚠️ 回退到原文: {text}")
        full_translation.append(translated or text)
        success_flags.append(translation_success)
        if idx < total_lines - 1:
            if MODEL_TYPE == ModelType.OLLAMA:
                time.sleep(0.5)
            else:
                time.sleep(0.2)
    return full_translation, success_flags

def translate(folder: str, target_language: str = '简体中文') -> bool:
    try:
        translation_path = os.path.join(folder, 'translation.json')
        if os.path.exists(translation_path):
            logger.info(f"📂 已存在翻译，跳过: {folder}")
            return True
        info_path = os.path.join(folder, 'download.info.json')
        transcript_path = os.path.join(folder, 'transcript.json')
        if not os.path.exists(info_path) or not os.path.exists(transcript_path):
            logger.error(f"❌ 缺少必要文件")
            return False
        with open(info_path, 'r', encoding='utf-8') as f:
            raw_info = json.load(f)
        info = get_necessary_info(raw_info)
        with open(transcript_path, 'r', encoding='utf-8') as f:
            original_transcript = json.load(f)
        logger.info(f"📄 加载了 {len(original_transcript)} 条原始字幕")
        summary_path = os.path.join(folder, 'summary.json')
        if os.path.exists(summary_path):
            try:
                with open(summary_path, 'r', encoding='utf-8') as f:
                    summary = json.load(f)
                logger.info("📥 加载现有摘要")
            except Exception as e:
                logger.warning(f"⚠️ 加载摘要失败，重新生成: {e}")
                summary = summarize_with_retry(info, original_transcript, target_language)
                with open(summary_path, 'w', encoding='utf-8') as f:
                    json.dump(summary, f, indent=2, ensure_ascii=False)
        else:
            logger.info("🔄 生成新摘要")
            summary = summarize_with_retry(info, original_transcript, target_language)
            with open(summary_path, 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)
        logger.info("🚀 开始翻译字幕...")
        translations, success_flags = _translate(summary, original_transcript, target_language)
        working_transcript = []
        for i, line in enumerate(original_transcript):
            translation_text = translations[i] if i < len(translations) else line.get('text', '')
            working_line = {
                "start": float(line.get('start', 0)),
                "end": float(line.get('end', 0)),
                "text": line.get('text', ''),
                "speaker": line.get('speaker', ''),
                "translation": translation_text
            }
            working_transcript.append(working_line)
        if SPLIT_SENTENCES:
            logger.info("🔧 拆分长句（修复版）...")
            final_transcript = split_sentences_fixed(working_transcript)
        else:
            logger.info("📝 保持句子原样，不拆分...")
            final_transcript = working_transcript
        logger.info("🔍 强制修正时间戳以确保与原始一致...")
        final_transcript = fix_timestamps(original_transcript, final_transcript)
        logger.info("✅ 验证时间戳一致性...")
        validate_time_alignment(original_transcript, final_transcript)
        for item in final_transcript:
            item["start"] = round(float(item.get("start", 0)), 3)
            item["end"] = round(float(item.get("end", 0)), 3)
        with open(translation_path, 'w', encoding='utf-8') as f:
            json.dump(final_transcript, f, indent=2, ensure_ascii=False)
        logger.info(f"✅ 翻译完成: {translation_path}")
        total = len(success_flags)
        success_count = sum(success_flags)
        failure_count = total - success_count
        logger.info(f"\n{'='*60}")
        logger.info(f"📊 翻译结果统计:")
        logger.info(f"  总计: {total} 句")
        logger.info(f"  成功: {success_count} 句 ({success_count/total*100:.1f}%)")
        logger.info(f"  失败: {failure_count} 句 ({failure_count/total*100:.1f}%)")
        if failure_count > 0:
            logger.warning(f"\n⚠️  以下句子翻译失败（回退到原文）:")
            for i, (line, success) in enumerate(zip(original_transcript, success_flags)):
                if not success:
                    text = line.get('text', '')[:100]
                    start = line.get('start', 0)
                    end = line.get('end', 0)
                    logger.warning(f"  [{i+1}] {start:.1f}s-{end:.1f}s: {text}...")
        stats_path = os.path.join(folder, 'translation_stats.json')
        stats = {
            'total_lines': total,
            'success_count': success_count,
            'failure_count': failure_count,
            'success_rate': round(success_count / total * 100, 2) if total > 0 else 0,
            'failed_lines': [
                {
                    'index': i,
                    'start': line.get('start'),
                    'end': line.get('end'),
                    'text': line.get('text', '')[:200]
                }
                for i, (line, success) in enumerate(zip(original_transcript, success_flags))
                if not success
            ]
        }
        with open(stats_path, 'w', encoding='utf-8') as f:
            json.dump(stats, f, indent=2, ensure_ascii=False)
        logger.info(f"📊 统计已保存: {stats_path}")
        return True
    except Exception as e:
        logger.error(f"❌ 翻译失败: {e}")
        logger.error(traceback.format_exc())
        return False

def translate_all_transcript_under_folder(root_folder: str, target_language: str = '简体中文') -> int:
    logger.info("🔍 检查模型服务...")
    if not check_model_health():
        logger.error("❌ 模型服务不可用")
        return 0
    count = 0
    failed = 0
    video_folders = []
    logger.info(f"📂 扫描目录: {root_folder}")
    for root, dirs, files in os.walk(root_folder):
        if 'transcript.json' in files and 'translation.json' not in files:
            video_folders.append(root)
    logger.info(f"🎯 找到 {len(video_folders)} 个需要翻译的视频")
    if not video_folders:
        logger.info("✅ 所有视频都已翻译完成")
        return 0
    for i, folder in enumerate(video_folders):
        logger.info(f"\n{'='*60}")
        logger.info(f"🎬 处理视频 ({i+1}/{len(video_folders)}):")
        logger.info(f"📁 目录: {folder}")
        try:
            start_time = time.time()
            if translate(folder, target_language):
                count += 1
                elapsed = time.time() - start_time
                logger.info(f"✅ 完成 ({elapsed:.1f}秒)")
            else:
                failed += 1
                logger.error(f"❌ 失败")
        except Exception as e:
            failed += 1
            logger.error(f"❌ 处理异常: {e}")
            logger.error(traceback.format_exc())
        if i < len(video_folders) - 1:
            wait_time = 1
            logger.info(f"⏳ 等待 {wait_time} 秒处理下一个...")
            time.sleep(wait_time)
    logger.info(f"\n{'='*60}")
    logger.info(f"🏁 翻译完成")
    logger.info(f"📈 总计: {len(video_folders)} 个视频")
    logger.info(f"✅ 成功: {count} 个")
    logger.info(f"❌ 失败: {failed} 个")
    return count

# ==================== 主程序 ====================
if __name__ == '__main__':
    logger.remove()
    logger.add(
        sys.stderr,
        level="INFO",
        format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{message}</cyan>",
        colorize=True
    )
    logger.add(
        "translation.log",
        level="DEBUG",
        rotation="10 MB",
        retention="7 days",
        encoding="utf-8",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {message}"
    )
    print("\n" + "="*60)
    print("🎬 视频字幕翻译工具 - VAD 时长感知版")
    print("="*60)
    logger.info(f"📦 模型类型: {MODEL_TYPE.value}")
    logger.info(f"🤖 模型名称: {MODEL_NAME}")
    logger.info(f"🌐 API地址: {API_BASE}")
    logger.info(f"🔑 API Key: {'已设置' if API_KEY else '未设置'}")
    logger.info(f"🔧 句子拆分: {'启用' if SPLIT_SENTENCES else '禁用（推荐）'}")
    logger.info("🧪 测试连接中...")
    try:
        import requests
        test_url = API_BASE.replace('/v1', '/api/tags') if '/v1' in API_BASE else f"{API_BASE}/api/tags"
        response = requests.get(test_url, timeout=10)
        if response.status_code == 200:
            models = response.json().get('models', [])
            model_names = [m['name'] for m in models]
            logger.info(f"✅ 连接成功! 可用模型: {', '.join(model_names)}")
        else:
            logger.warning(f"⚠️ 连接测试状态码: {response.status_code}")
    except Exception as e:
        logger.warning(f"⚠️ 连接测试异常: {e}")
    print("="*60 + "\n")
    success_count = translate_all_transcript_under_folder(
        r'videos',
        '简体中文'
    )
    if success_count > 0:
        logger.info(f"🎉 成功翻译 {success_count} 个视频")
    else:
        logger.info("ℹ️  没有需要翻译的视频或翻译失败")