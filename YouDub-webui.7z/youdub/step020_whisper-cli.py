"""
音频转录 + 说话人分离（基于 whisper-cli + pyannote.audio）
改进版：解决重复文本问题 + 智能分段

- 使用本地 whisper-cli.exe 做 ASR（稳定、快速、无需 Python 依赖）
- 使用 pyannote.audio 做说话人分离（需 HF_TOKEN）
- 自动跳过已处理文件夹
- 输出格式兼容你原有的 whisperx 脚本
- 新增：清理whisper重复输出 + 智能断句

作者：基于你的需求重构
日期：2026-01-01
版本：3.0
"""

import os
import sys
import json
import re
import subprocess
import numpy as np
from typing import List, Optional, Tuple, Dict
from dataclasses import dataclass

# ==================== 配置 ====================
WHISPER_DIR = r"C:\whisper-cublas-12.4.0-bin-x64\Release"
WHISPER_EXE = os.path.join(WHISPER_DIR, "whisper-cli.exe")
WHISPER_MODEL = os.path.join(WHISPER_DIR, "ggml-large-v3-q5_0.bin")

# ==================== 导入依赖 ====================
import torch
from dotenv import load_dotenv
from loguru import logger

load_dotenv()

# ==================== 配置参数 ====================
@dataclass
class SegmentConfig:
    """分段配置参数"""
    # 合并参数
    max_segment_duration: float = 12.0      # 单个段落最大时长（秒）
    max_segment_chars: int = 300            # 单个段落最大字符数
    min_segment_duration: float = 0.8       # 单个段落最小时长（秒）
    min_segment_chars: int = 15             # 单个段落最小字符数
    max_pause_duration: float = 1.2         # 最大停顿时间，超过此值会断开
    
    # 去重参数
    duplicate_threshold: float = 0.6        # 重复检测阈值
    min_text_for_dedup: int = 20            # 去重的最小文本长度
    
    # 切分参数
    max_sentence_chars: int = 150           # 单个句子最大字符数（用于二次切分）
    min_sentence_chars: int = 40            # 单个句子最小字符数
    sentence_endings: tuple = ('.', '?', '!', '。', '？', '！', ';', ':')
    continue_words: set = None              # 表示句子继续的词
    
    def __post_init__(self):
        if self.continue_words is None:
            self.continue_words = {
                'and', 'but', 'or', 'so', 'because', 'although', 'while',
                'the', 'a', 'an', 'to', 'for', 'with', 'by', 'as', 'in',
                'on', 'at', 'from', 'into', 'during', 'including', 'until',
                'that', 'which', 'who', 'whom', 'whose', 'what',
                '例如', '比如', '然而', '但是', '而且', '所以', '因为'
            }

# 全局配置实例
config = SegmentConfig()

# ==================== 全局变量 ====================
diarize_pipeline = None

# ==================== 工具函数 ====================

def time_str_to_seconds(time_str: str) -> float:
    """将 HH:MM:SS.mmm 转为秒数"""
    parts = time_str.split(':')
    if len(parts) == 3:
        h, m, s = parts
        return int(h) * 3600 + int(m) * 60 + float(s)
    return 0.0


def parse_whisper_stdout(stdout: str) -> List[dict]:
    """解析 whisper-cli 的 stdout，返回带 start/end/text 的列表"""
    segments = []
    lines = stdout.strip().split('\n')
    pattern = r'\[(\d{2}:\d{2}:\d{2}\.\d{3})\s*-->\s*(\d{2}:\d{2}:\d{2}\.\d{3})\]\s*(.+)'
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        match = re.match(pattern, line)
        if match:
            try:
                start_ts, end_ts, text = match.groups()
                start = time_str_to_seconds(start_ts)
                end = time_str_to_seconds(end_ts)
                segments.append({
                    "start": start,
                    "end": end,
                    "text": text.strip()
                })
            except Exception as e:
                logger.warning(f"解析失败: {e}, 行: {line[:50]}")
    return segments


def convert_to_16k_mono(input_path: str) -> str:
    """转换音频为 16kHz 单声道 WAV（whisper 最佳输入）"""
    if input_path.lower().endswith('.wav'):
        # 快速检查是否已是 16k/mono
        try:
            import librosa
            y, sr = librosa.load(input_path, sr=None, mono=None)
            if sr == 16000 and y.ndim == 1:
                return input_path
        except:
            pass

    # 转换
    base = os.path.splitext(os.path.basename(input_path))[0]
    output = f"temp_{base}_16k.wav"
    cmd = [
        "ffmpeg", "-i", input_path,
        "-ar", "16000", "-ac", "1", "-y",
        "-loglevel", "error", output
    ]
    subprocess.run(cmd, check=True, timeout=300)
    return output


# ==================== 文本清理模块 ====================

def fix_common_whisper_errors(text: str) -> str:
    """修复whisper常见的转录错误"""
    if not text:
        return text
    
    # 修复常见的错误标点
    replacements = [
        (' ,', ','),
        (' .', '.'),
        (' ?', '?'),
        (' !', '!'),
        (' ;', ';'),
        (' :', ':'),
        ('( ', '('),
        (' )', ')'),
        ('[ ', '['),
        (' ]', ']'),
        ('{ ', '{'),
        (' }', '}'),
        ('  ', ' '),
    ]
    
    for old, new in replacements:
        text = text.replace(old, new)
    
    return text.strip()


def is_gibberish(text: str) -> bool:
    """判断文本是否无意义"""
    if not text:
        return True
    
    # 太短
    if len(text) < 3:
        return True
    
    # 检查是否包含太多非字母字符
    letters = sum(c.isalpha() for c in text)
    if letters < len(text) * 0.3:  # 少于30%字母
        return True
    
    return False


def calculate_text_overlap(text1: str, text2: str) -> float:
    """计算两段文本的重叠度 (0-1)"""
    if not text1 or not text2:
        return 0.0
    
    words1 = text1.lower().split()
    words2 = text2.lower().split()
    
    if not words1 or not words2:
        return 0.0
    
    # 检查结尾和开头的重叠
    max_overlap = 0
    for i in range(1, min(len(words1), len(words2), 10) + 1):  # 最多检查10个词
        if words1[-i:] == words2[:i]:
            max_overlap = i
            break
    
    return max_overlap / min(len(words1), len(words2))


def merge_overlapping_text(text1: str, text2: str) -> str:
    """合并两段重叠的文本"""
    if not text1:
        return text2
    if not text2:
        return text1
    
    # 情况1: text2是text1的扩展
    if text2.startswith(text1):
        return text2
    
    # 情况2: text1是text2的扩展
    if text1.startswith(text2):
        return text1
    
    # 情况3: 部分重叠
    words1 = text1.split()
    words2 = text2.split()
    
    # 查找重叠部分
    for overlap in range(min(len(words1), len(words2), 5), 0, -1):  # 最多5个词
        if words1[-overlap:] == words2[:overlap]:
            # 合并，去除重叠部分
            return ' '.join(words1 + words2[overlap:])
    
    # 没有重叠，返回两者合并
    return f"{text1} {text2}"


def remove_internal_repetition(text: str) -> str:
    """移除文本内部的重复短语"""
    if len(text) < 50:
        return text
    
    words = text.split()
    if len(words) < 8:
        return text
    
    # 查找3词短语的重复
    seen_phrases = set()
    result_words = []
    
    i = 0
    while i < len(words):
        # 检查从当前位置开始的3词短语
        if i <= len(words) - 3:
            phrase = ' '.join(words[i:i+3])
            if phrase in seen_phrases:
                # 跳过重复短语
                i += 3
                continue
            seen_phrases.add(phrase)
        
        result_words.append(words[i])
        i += 1
    
    result = ' '.join(result_words)
    
    # 如果清理后太短，返回原始文本
    if len(result) < len(text) * 0.6:
        return text
    
    return result


def clean_whisper_segments(segments: List[dict]) -> List[dict]:
    """
    清理whisper的输出，解决重复文本问题
    返回清理后的段落列表
    """
    if not segments:
        return segments
    
    cleaned = []
    
    for i, seg in enumerate(segments):
        text = seg["text"].strip()
        if not text:
            continue
        
        # 1. 基本清理
        text = fix_common_whisper_errors(text)
        
        # 2. 跳过无意义文本
        if is_gibberish(text):
            logger.debug(f"跳过无意义文本: {text[:50]}...")
            continue
        
        # 3. 检查与上一段的重复/重叠
        if cleaned:
            prev_seg = cleaned[-1]
            prev_text = prev_seg["text"]
            
            # 计算重叠度
            overlap_score = calculate_text_overlap(prev_text, text)
            
            if overlap_score > config.duplicate_threshold:
                # 高度重叠，合并文本
                merged_text = merge_overlapping_text(prev_text, text)
                if merged_text != prev_text:  # 如果有改进
                    logger.debug(f"合并重叠文本 (重叠度: {overlap_score:.2f})")
                    logger.debug(f"  前: {prev_text[-50:]}")
                    logger.debug(f"  后: {text[:50]}")
                    logger.debug(f"  合: {merged_text[-80:]}")
                    
                    prev_seg["text"] = merged_text
                    prev_seg["end"] = seg["end"]
                continue
        
        # 4. 清理段落内重复
        deduped_text = remove_internal_repetition(text)
        if deduped_text != text:
            logger.debug(f"清理内部重复: {len(text)} -> {len(deduped_text)} 字符")
            text = deduped_text
        
        # 5. 确保文本有意义
        if len(text) < config.min_segment_chars or text.count(' ') < 2:
            # 太短，尝试与下一段合并
            if i < len(segments) - 1:
                next_seg = segments[i + 1]
                next_text = next_seg["text"].strip()
                if next_text:
                    # 合并到下一段
                    segments[i + 1]["text"] = f"{text} {next_text}"
                    segments[i + 1]["start"] = seg["start"]
                    continue
            else:
                continue  # 跳过太短的尾段
        
        # 添加到结果
        seg_copy = seg.copy()
        seg_copy["text"] = text
        cleaned.append(seg_copy)
    
    logger.info(f"🧹 文本清理: {len(segments)} -> {len(cleaned)} 段")
    return cleaned


# ==================== 智能切分模块 ====================

def split_long_sentence(text: str, max_chars: int = None) -> List[str]:
    """
    将长句子切分为较短的句子
    基于自然语言规则进行智能切分
    """
    if max_chars is None:
        max_chars = config.max_sentence_chars
    
    if len(text) <= max_chars:
        return [text]
    
    sentences = []
    current = []
    words = text.split()
    
    for i, word in enumerate(words):
        current.append(word)
        current_text = ' '.join(current)
        
        # 检查是否应该在此处切分
        should_split = False
        
        # 1. 长度超过限制
        if len(current_text) > max_chars:
            should_split = True
        
        # 2. 找到句子结束点
        elif i < len(words) - 1:
            # 当前词以句子结束标点结尾
            if word.endswith(config.sentence_endings):
                should_split = True
            
            # 下一词以大写开头（可能是新句子）
            elif (words[i + 1][0].isupper() if words[i + 1] else False):
                # 但排除一些特殊情况
                if word.lower() not in config.continue_words:
                    should_split = True
        
        if should_split:
            # 确保当前句子不要太短
            if len(current_text) >= config.min_sentence_chars:
                sentences.append(current_text)
                current = []
            # 如果太短，继续累积
    
    # 添加剩余部分
    if current:
        current_text = ' '.join(current)
        if len(current_text) >= config.min_sentence_chars:
            sentences.append(current_text)
        elif sentences:
            # 合并到最后一句
            sentences[-1] = f"{sentences[-1]} {current_text}"
    
    # 如果还是太长，强制切分
    if len(sentences) == 1 and len(sentences[0]) > max_chars * 1.5:
        # 按标点切分
        result = []
        parts = re.split(r'([.!?;:]+)', sentences[0])
        
        current_part = ""
        for part in parts:
            current_part += part
            if len(current_part) > max_chars:
                if part.endswith(config.sentence_endings):
                    result.append(current_part)
                    current_part = ""
        
        if current_part:
            if result:
                result[-1] = f"{result[-1]}{current_part}"
            else:
                result.append(current_part)
        
        return result
    
    return sentences


def split_long_segment(segment: dict) -> List[dict]:
    """
    将过长的段落切分为多个较短段落
    保持时间戳的合理分配
    """
    text = segment["text"]
    start = segment["start"]
    end = segment["end"]
    speaker = segment.get("speaker", "SPEAKER_00")
    
    # 如果段落不长，直接返回
    if (end - start) <= config.max_segment_duration and len(text) <= config.max_segment_chars:
        return [segment]
    
    # 切分句子
    sentences = split_long_sentence(text)
    if len(sentences) == 1:
        return [segment]
    
    # 分配时间戳
    total_chars = len(text)
    duration = end - start
    
    segments = []
    current_start = start
    
    for i, sentence in enumerate(sentences):
        # 按字符比例分配时间
        sentence_chars = len(sentence)
        sentence_duration = duration * (sentence_chars / total_chars)
        
        # 最后一个句子调整到准确结束时间
        if i == len(sentences) - 1:
            sentence_end = end
        else:
            sentence_end = current_start + sentence_duration
        
        segments.append({
            "start": current_start,
            "end": sentence_end,
            "text": sentence,
            "speaker": speaker
        })
        
        current_start = sentence_end
    
    logger.debug(f"切分段落: {len(text)}字符 -> {len(segments)}个句子")
    return segments


def split_all_long_segments(segments: List[dict]) -> List[dict]:
    """切分所有过长的段落"""
    result = []
    for seg in segments:
        split_segs = split_long_segment(seg)
        result.extend(split_segs)
    
    if len(result) > len(segments):
        logger.info(f"✂️ 段落切分: {len(segments)} -> {len(result)} 段")
    
    return result


# ==================== 智能合并模块 ====================

def should_merge_segments(prev: dict, curr: dict) -> Tuple[bool, str]:
    """
    判断两个段落是否应该合并
    返回：(是否应该合并, 原因)
    """
    # 1. 必须是同一个说话人
    if prev.get("speaker") != curr.get("speaker"):
        return False, "不同说话人"
    
    # 2. 检查停顿时间
    pause_duration = curr["start"] - prev["end"]
    if pause_duration > config.max_pause_duration:
        return False, f"停顿时间过长: {pause_duration:.2f}s"
    
    # 3. 检查合并后的时长
    merged_duration = curr["end"] - prev["start"]
    if merged_duration > config.max_segment_duration:
        return False, f"合并后时长过长: {merged_duration:.2f}s"
    
    # 4. 检查合并后的字符数
    merged_text = f"{prev['text']} {curr['text']}"
    if len(merged_text) > config.max_segment_chars:
        return False, f"合并后字符数过多: {len(merged_text)}"
    
    # 5. 检查前一段是否太短（需要合并）
    prev_duration = prev["end"] - prev["start"]
    prev_text_len = len(prev["text"])
    
    if prev_duration < config.min_segment_duration or prev_text_len < config.min_segment_chars:
        return True, f"前一段过短: {prev_duration:.2f}s/{prev_text_len}字符"
    
    # 6. 基于文本内容的判断
    prev_text = prev["text"].strip()
    curr_text = curr["text"].strip()
    
    # 如果前一句以结束标点结尾，通常应该断开
    if prev_text and prev_text[-1] in config.sentence_endings:
        # 除非是非常短的句子
        if prev_text_len < 30:
            return True, "短句以结束标点结尾，但过短"
        return False, "以结束标点结尾"
    
    # 检查是否以连接词结尾
    last_few_words = prev_text.lower().split()[-2:] if ' ' in prev_text else [prev_text.lower()]
    for word in last_few_words:
        clean_word = word.strip('.,!?;:()[]{}"\'').lower()
        if clean_word in config.continue_words:
            return True, f"以连接词结尾: {clean_word}"
    
    # 默认：保持分开（保守策略）
    return False, "默认保持分开"


def merge_segments(segments: List[dict]) -> List[dict]:
    """
    智能合并段落，避免过度合并
    保持自然的断句，同时合并明显被错误分割的短句
    """
    if not segments:
        return segments
    
    merged = []
    current = segments[0].copy()
    
    for i in range(1, len(segments)):
        next_seg = segments[i]
        should_merge, reason = should_merge_segments(current, next_seg)
        
        if should_merge:
            # 合并段落
            current["text"] = f"{current['text']} {next_seg['text']}".strip()
            current["end"] = next_seg["end"]
            logger.debug(f"合并段落 {i}: {reason}")
        else:
            # 保存当前段落，开始新的
            merged.append(current)
            current = next_seg.copy()
            logger.debug(f"断开段落 {i}: {reason}")
    
    # 添加最后一个段落
    merged.append(current)
    
    # 最终清理
    final_segments = []
    for seg in merged:
        seg["text"] = seg["text"].strip()
        if seg["text"] and (seg["end"] - seg["start"]) >= 0.1:
            final_segments.append(seg)
    
    logger.info(f"📊 段落合并: 原始 {len(segments)} -> 合并后 {len(final_segments)}")
    return final_segments


# ==================== 说话人分离模块 ====================

def load_diarization_pipeline():
    """加载 pyannote 说话人分离模型（单例）"""
    global diarize_pipeline
    if diarize_pipeline is not None:
        return diarize_pipeline

    hf_token = os.getenv("HF_TOKEN")
    if not hf_token:
        raise RuntimeError("❌ 请在 .env 文件中设置 HF_TOKEN")

    logger.info("🧠 加载 PyAnnote 说话人分离模型（首次下载约 500MB）...")
    from pyannote.audio import Pipeline
    diarize_pipeline = Pipeline.from_pretrained(
        "pyannote/speaker-diarization-3.1",
        use_auth_token=hf_token
    ).to(torch.device("cuda" if torch.cuda.is_available() else "cpu"))
    
    logger.info("✅ 说话人模型加载完成")
    return diarize_pipeline


from pyannote.core import Annotation, Segment

def assign_speakers_to_segments(segments: List[dict], diarization_result: Annotation) -> List[dict]:
    """将说话人标签分配给每个转录段落"""
    new_segments = []
    for seg in segments:
        start = seg["start"]
        end = seg["end"]
        query_segment = Segment(start, end)
        cropped = diarization_result.crop(query_segment)
        
        if len(cropped) == 0:
            speaker = "SPEAKER_00"
        else:
            try:
                speaker = str(cropped.argmax())
            except Exception:
                speaker = "SPEAKER_00"

        new_segments.append({
            "start": start,
            "end": end,
            "text": seg["text"],
            "speaker": speaker
        })
    return new_segments


# ==================== 输出模块 ====================

def save_transcript(folder: str, segments: List[dict]):
    """保存 transcript.json（兼容 whisperx 格式）"""
    transcript_path = os.path.join(folder, "transcript.json")
    with open(transcript_path, "w", encoding="utf-8") as f:
        json.dump(segments, f, ensure_ascii=False, indent=4)
    
    # 统计信息
    if segments:
        total_duration = segments[-1]["end"]
        avg_duration = sum(s["end"] - s["start"] for s in segments) / len(segments)
        avg_chars = sum(len(s["text"]) for s in segments) / len(segments)
        
        logger.info(f"✅ transcript.json 已保存: {transcript_path}")
        logger.info(f"   段落数: {len(segments)}, 总时长: {total_duration:.1f}s")
        logger.info(f"   平均每段: {avg_duration:.1f}s, {avg_chars:.0f}字符")
        
        # 检查过长段落
        for i, seg in enumerate(segments[:10]):  # 只检查前10段
            duration = seg["end"] - seg["start"]
            chars = len(seg["text"])
            if duration > config.max_segment_duration:
                logger.warning(f"   段落 {i} 过长: {duration:.1f}s ({chars}字符)")
            if chars > config.max_segment_chars:
                logger.warning(f"   段落 {i} 字符过多: {chars}字符 ({duration:.1f}s)")
    else:
        logger.warning("❌ 没有段落可保存")


def generate_speaker_audio(folder: str, segments: List[dict]):
    """为每个说话人生成独立音频文件"""
    try:
        import librosa
    except ImportError:
        logger.warning("❌ 需要 librosa 来生成说话人音频")
        return
    
    wav_path = os.path.join(folder, "audio_vocals.wav")
    if not os.path.exists(wav_path):
        logger.warning(f"⚠️ 音频文件不存在: {wav_path}")
        return
    
    try:
        audio, sr = librosa.load(wav_path, sr=24000, mono=True)
    except Exception as e:
        logger.error(f"❌ 加载音频失败: {e}")
        return
    
    try:
        from youdub.utils import save_wav
    except ImportError:
        try:
            import soundfile as sf
            def save_wav(audio_data, path, sample_rate=24000):
                sf.write(path, audio_data, sample_rate)
        except ImportError:
            logger.warning("❌ 需要 soundfile 或 youdub 来保存音频")
            return
    
    speaker_chunks = {}
    delay = 0.05  # 前后扩展 50ms
    
    for seg in segments:
        start = max(0, int((seg["start"] - delay) * sr))
        end = min(len(audio), int((seg["end"] + delay) * sr))
        chunk = audio[start:end]
        spk = seg["speaker"]
        speaker_chunks.setdefault(spk, []).append(chunk)
    
    out_dir = os.path.join(folder, "SPEAKER")
    os.makedirs(out_dir, exist_ok=True)
    
    for spk, chunks in speaker_chunks.items():
        out_path = os.path.join(out_dir, f"{spk}.wav")
        if chunks:
            combined = np.concatenate(chunks)
            save_wav(combined, out_path, sample_rate=sr)
            logger.info(f"🔊 生成说话人音频: {out_path} ({len(chunks)}个片段)")
    
    logger.info(f"🎵 音频生成完成，共 {len(speaker_chunks)} 个说话人")


# ==================== 主处理函数 ====================

def transcribe_folder(folder: str, diarization: bool = True) -> bool:
    """处理单个文件夹：ASR + 说话人分离 + 智能分段"""
    transcript_path = os.path.join(folder, "transcript.json")
    if os.path.exists(transcript_path):
        logger.info(f"⏩ 已存在 transcript.json，跳过: {folder}")
        return True
    
    wav_path = os.path.join(folder, "audio_vocals.wav")
    if not os.path.exists(wav_path):
        logger.warning(f"⚠️ 缺少音频文件: {wav_path}")
        return False
    
    logger.info(f"🎙️ 开始处理: {wav_path}")
    
    # === Step 1: 使用 whisper-cli 转录 ===
    try:
        converted_wav = convert_to_16k_mono(wav_path)
        
        cmd = [
            WHISPER_EXE,
            "--model", WHISPER_MODEL,
            "--file", os.path.abspath(converted_wav),
            "--language", "auto",
            "--threads", "4",
            "--output-txt",
            "--print-progress"
        ]
        
        logger.info(f"执行命令: {' '.join(cmd)}")
        result = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=WHISPER_DIR,
            encoding='utf-8',
            errors='replace',
            timeout=1800
        )
        
        if result.returncode != 0:
            logger.error(f"❌ whisper-cli 失败: {result.stderr[:500]}")
            return False
        
        segments = parse_whisper_stdout(result.stdout)
        if not segments:
            logger.error("❌ 未解析到任何转录结果")
            return False
        
        logger.info(f"✅ ASR 完成，共 {len(segments)} 个原始段落")
        
        # 临时文件清理
        if converted_wav != wav_path and os.path.exists(converted_wav):
            os.remove(converted_wav)
            
    except subprocess.TimeoutExpired:
        logger.error("❌ whisper-cli 执行超时")
        return False
    except Exception as e:
        logger.error(f"❌ ASR 过程出错: {e}")
        return False
    
    # === Step 2: 清理whisper重复输出 ===
    segments = clean_whisper_segments(segments)
    
    # === Step 3: 说话人分离（可选）===
    if diarization:
        try:
            import librosa
            pipeline = load_diarization_pipeline()
            audio_16k, _ = librosa.load(wav_path, sr=16000, mono=True)
            diarization_result = pipeline({
                "waveform": torch.from_numpy(audio_16k).unsqueeze(0),
                "sample_rate": 16000
            })
            logger.debug(f"说话人分段数: {len(list(diarization_result.get_timeline()))}")
            segments = assign_speakers_to_segments(segments, diarization_result)
            logger.info("✅ 说话人分离完成")
        except ImportError:
            logger.warning("❌ 需要 librosa 进行说话人分离，跳过此步骤")
            for seg in segments:
                seg["speaker"] = "SPEAKER_00"
        except Exception as e:
            logger.error(f"❌ 说话人分离失败: {e}")
            for seg in segments:
                seg["speaker"] = "SPEAKER_00"
    else:
        for seg in segments:
            seg["speaker"] = "SPEAKER_00"
    
    # === Step 4: 智能合并短段落 ===
    segments = merge_segments(segments)
    
    # === Step 5: 切分过长段落 ===
    segments = split_all_long_segments(segments)
    
    # === Step 6: 最终合并（处理切分后可能产生的过短段落）===
    segments = merge_segments(segments)
    
    # === Step 7: 保存结果 ===
    save_transcript(folder, segments)
    
    # === Step 8: 生成说话人音频 ===
    try:
        generate_speaker_audio(folder, segments)
    except Exception as e:
        logger.error(f"❌ 生成说话人音频失败: {e}")
    
    return True


def transcribe_all_folders(root_dir: str, diarization: bool = True):
    """批量处理所有包含 audio_vocals.wav 的子文件夹"""
    logger.info(f"🔍 扫描目录: {root_dir}")
    count = 0
    success = 0
    
    for root, _, files in os.walk(root_dir):
        if "audio_vocals.wav" in files:
            logger.info(f"\n{'='*60}")
            logger.info(f"📁 处理文件夹: {root}")
            if transcribe_folder(root, diarization=diarization):
                success += 1
            count += 1
    
    logger.info(f"\n{'='*60}")
    logger.info(f"🎉 处理完成！总计: {count} 个文件夹，成功: {success}")


# ==================== 主程序 ====================

if __name__ == "__main__":
    # 配置日志
    logger.remove()
    logger.add(
        sys.stderr,
        level="INFO",
        format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <level>{message}</level>"
    )
    
    # 检查依赖
    if not os.path.exists(WHISPER_EXE):
        logger.error(f"❌ whisper-cli 不存在: {WHISPER_EXE}")
        sys.exit(1)
    
    # 显示配置
    logger.info(f"📝 配置参数:")
    logger.info(f"   最大段落: {config.max_segment_duration}s, {config.max_segment_chars}字符")
    logger.info(f"   最小段落: {config.min_segment_duration}s, {config.min_segment_chars}字符")
    logger.info(f"   最大停顿: {config.max_pause_duration}s")
    logger.info(f"   重复阈值: {config.duplicate_threshold}")
    
    # 运行
    try:
        transcribe_all_folders(
            root_dir="videos",  # 修改为你的目录
            diarization=True    # 设为 False 可跳过说话人分离
        )
    except KeyboardInterrupt:
        logger.warning("⏹️ 用户中断")
    except Exception as e:
        logger.error(f"❌ 主程序异常: {e}")
        import traceback
        traceback.print_exc()