#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
语音合成与音频处理脚本 - VAD 时长感知版（适配 XTTS speed 参数）
优化版：全程内存处理 + 鲁棒时长控制 + 预分配轨道

作者: [Your Name]
创建日期: 2026-01-02
版本: 1.5 - 优化流程（内存化、鲁棒性、效率）
"""

import json
import os
import re
import librosa
import sys
import traceback
import time
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass
import numpy as np

from loguru import logger

# 加载 .env（用于 HF_TOKEN）
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    logger.warning("未安装 python-dotenv，将尝试从环境变量读取 HF_TOKEN")

# 添加父目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入自定义模块（带错误处理）
try:
    from youdub.utils import save_wav, save_wav_norm
except ImportError:
    logger.warning("youdub.utils 模块导入失败，将使用本地实现")
    import scipy.io.wavfile
    
    def save_wav(wav: np.ndarray, path: str, sample_rate: int = 24000):
        scipy.io.wavfile.write(path, sample_rate, (wav * 32767).astype(np.int16))
    
    def save_wav_norm(wav: np.ndarray, path: str, sample_rate: int = 24000):
        if len(wav) > 0:
            wav = wav / np.max(np.abs(wav)) * 0.95
        save_wav(wav, path, sample_rate)

# TTS 引擎导入
HAS_BYTEDANCE = False
HAS_XTTS = False

try:
    from youdub.step041_tts_bytedance import tts as bytedance_tts
    HAS_BYTEDANCE = True
    logger.info("✅ 字节跳动TTS模块加载成功")
except ImportError as e:
    logger.warning(f"⚠️ 字节跳动TTS模块导入失败: {e}")
    def bytedance_tts(*args, **kwargs):
        logger.error("字节跳动TTS不可用")
        return False

try:
    from youdub.step042_tts_xtts import tts as xtts_tts, load_model
    HAS_XTTS = True
    logger.info("✅ XTTS模块加载成功")
    try:
        load_model()
        logger.info("✅ XTTS模型预加载成功")
    except Exception as e:
        logger.warning(f"⚠️ XTTS模型预加载失败: {e}")
except ImportError as e:
    logger.error(f"❌ XTTS模块导入失败: {e}")
    def xtts_tts(*args, **kwargs):
        logger.error("XTTS不可用")
        return False
    def load_model():
        return False

# 文本规范化
try:
    from youdub.cn_tx import TextNorm
    normalizer = TextNorm()
    HAS_TEXTNORM = True
except ImportError:
    HAS_TEXTNORM = False
    logger.warning("⚠️ 文本规范化模块未找到")

# 音频拉伸
try:
    from audiostretchy.stretch import stretch_wave
    HAS_AUDIOSTRETCHY = True
except ImportError:
    HAS_AUDIOSTRETCHY = False
    logger.warning("⚠️ audiostretchy未安装，将使用librosa")

@dataclass
class TTSConfig:
    force_bytedance: bool = True
    use_local_xtts: bool = False
    xtts_model_path: Optional[str] = None
    bytedance_voice: str = 'BV701_streaming'
    enable_post_speedup: bool = True
    post_speed_factor: float = 1.3
    min_speed_factor: float = 0.95
    max_speed_factor: float = 1.05
    sample_rate: int = 24000

# === 新增常量 ===
MIN_SAFE_DURATION = 0.3  # 秒，防止 TTS 失败
MAX_DURATION_FACTOR = 1.2  # vad_duration 最多比原始长 20%

def preprocess_text(text: str) -> str:
    if not text or not isinstance(text, str):
        return ""
    
    text = text.strip()
    if len(re.sub(r'\s', '', text)) < 2:  # 过滤极短文本
        return ""
    
    replacements = {
        'AI': '人工智能',
        'GPT': 'G P T',
        'API': 'A P I',
        'UI': 'U I',
        'UX': 'U X',
        'CEO': 'C E O',
        'CPU': 'C P U',
        'GPU': 'G P U',
    }
    
    for key, value in replacements.items():
        text = text.replace(key, value)
    
    text = re.sub(r'(?<!^)([A-Z])', r' \1', text)
    
    if HAS_TEXTNORM:
        try:
            text = normalizer(text)
        except:
            logger.warning("文本规范化失败")
    
    text = re.sub(r'(?<=[a-zA-Z])(?=\d)|(?<=\d)(?=[a-zA-Z])', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    
    return text.strip()

def adjust_audio_length_in_memory(
    wav: np.ndarray,
    target_duration: float,
    sample_rate: int = 24000,
    min_speed_factor: float = 0.95,
    max_speed_factor: float = 1.05
) -> np.ndarray:
    """纯内存音频拉伸，无文件 I/O"""
    if len(wav) == 0:
        return np.zeros(int(target_duration * sample_rate), dtype=np.float32)
    
    current_duration = len(wav) / sample_rate
    if current_duration <= 0:
        return np.zeros(int(target_duration * sample_rate), dtype=np.float32)
    
    speed_factor = np.clip(target_duration / current_duration, min_speed_factor, max_speed_factor)
    
    try:
        if HAS_AUDIOSTRETCHY:
            wav_stretched = stretch_wave(wav, ratio=1.0 / speed_factor, sample_rate=sample_rate)
        else:
            wav_stretched = librosa.effects.time_stretch(wav, rate=speed_factor)
        
        target_samples = int(target_duration * sample_rate)
        if len(wav_stretched) < target_samples:
            wav_stretched = np.pad(wav_stretched, (0, target_samples - len(wav_stretched)), mode='constant')
        else:
            wav_stretched = wav_stretched[:target_samples]
        return wav_stretched.astype(np.float32)
    except Exception as e:
        logger.warning(f"音频拉伸失败，返回静音: {e}")
        return np.zeros(int(target_duration * sample_rate), dtype=np.float32)

def choose_tts_engine(num_speakers: int, config: TTSConfig) -> str:
    if config.force_bytedance and HAS_BYTEDANCE:
        return 'bytedance'
    if config.use_local_xtts and HAS_XTTS:
        return 'xtts'
    if num_speakers == 1 and HAS_BYTEDANCE:
        return 'bytedance'
    if num_speakers > 1 and HAS_XTTS:
        return 'xtts'
    if HAS_BYTEDANCE:
        return 'bytedance'
    logger.error("❌ 没有可用的TTS引擎")
    return 'none'

def generate_tts_audio_to_memory(
    text: str, 
    speaker_wav: Optional[str], 
    engine: str, 
    config: TTSConfig, 
    target_duration: float
) -> Optional[np.ndarray]:
    """生成 TTS 音频并返回 numpy array，失败返回 None"""
    temp_path = None
    try:
        temp_path = os.path.join(os.path.dirname(speaker_wav or "."), "temp_tts.wav") if speaker_wav else "temp_tts.wav"
        
        if engine == 'bytedance' and HAS_BYTEDANCE:
            success = bytedance_tts(
                text=text,
                output_path=temp_path,
                speaker_wav=speaker_wav,
                voice_type=config.bytedance_voice
            )
            if not success:
                return None
            wav, _ = librosa.load(temp_path, sr=config.sample_rate)
            return wav
            
        elif engine == 'xtts' and HAS_XTTS:
            # 动态 speed
            expected_duration = max(0.5, len(text) / 4.5)
            speed = np.clip(expected_duration / target_duration, 0.7, 2.5)
            logger.debug(f"⏱️ 动态 speed: {speed:.2f} (目标 {target_duration:.2f}s, 预期 {expected_duration:.2f}s)")
            
            success = xtts_tts(
                text=text,
                output_path=temp_path,
                speaker_wav=speaker_wav,
                speed=speed,
                temperature=0.7,
                enable_post_speedup=config.enable_post_speedup,
                post_speed_factor=config.post_speed_factor
            )
            if not success:
                return None
            wav, _ = librosa.load(temp_path, sr=config.sample_rate)
            return wav
        else:
            logger.error(f"不支持的TTS引擎: {engine}")
            return None
    except Exception as e:
        logger.error(f"TTS生成失败: {e}")
        logger.error(f"文本: {text[:100]}")
        return None
    finally:
        if temp_path and os.path.exists(temp_path):
            try:
                os.remove(temp_path)
            except:
                pass

def generate_wavs(folder: str, config: Optional[TTSConfig] = None) -> bool:
    if config is None:
        config = TTSConfig()
    
    transcript_path = os.path.join(folder, 'translation.json')
    output_folder = os.path.join(folder, 'wavs')
    
    if not os.path.exists(transcript_path):
        logger.error(f"❌ 翻译文件不存在: {transcript_path}")
        return False
    
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    
    try:
        with open(transcript_path, 'r', encoding='utf-8') as f:
            transcript = json.load(f)
        
        if not transcript:
            logger.error(f"❌ 翻译文件为空: {transcript_path}")
            return False
        
        # 获取原始音频总时长
        audio_vocals_path = os.path.join(folder, 'audio_vocals.wav')
        if os.path.exists(audio_vocals_path):
            original_audio_duration = librosa.get_duration(path=audio_vocals_path)
        else:
            original_audio_duration = max(line.get('end', 0) for line in transcript)
        logger.info(f"⏱️ 原始音频总时长: {original_audio_duration:.2f}秒")
        
        # 识别说话人
        speakers = {line.get('speaker', 'SPEAKER_00') for line in transcript}
        num_speakers = len(speakers)
        logger.info(f'👥 发现 {num_speakers} 个说话人: {sorted(speakers)}')
        
        # 选择TTS引擎
        engine = choose_tts_engine(num_speakers, config)
        if engine == 'none':
            return False
        logger.info(f'🤖 使用TTS引擎: {engine}')
        
        # 预分配完整音频轨道
        total_samples = int(original_audio_duration * config.sample_rate)
        full_wav = np.zeros(total_samples, dtype=np.float32)
        
        for i, line in enumerate(transcript):
            start_sec = float(line.get('start', 0))
            end_sec = float(line.get('end', 0))
            raw_duration = end_sec - start_sec
            
            if raw_duration <= 0:
                continue
                
            original_text = line.get('translation', '').strip()
            if not original_text:
                logger.warning(f"⚠️ 第{i}行文本为空，跳过")
                continue
            
            text = preprocess_text(original_text)
            if not text:
                logger.warning(f"⚠️ 第{i}行预处理后为空，跳过")
                continue
                
            logger.debug(f"🔤 处理片段 {i}: {text[:50]}...")
            
            # 查找参考音频
            speaker_wav = None
            speaker_dir = os.path.join(folder, 'SPEAKER')
            if os.path.exists(speaker_dir):
                speaker = line.get('speaker', 'SPEAKER_00')
                cand_path = os.path.join(speaker_dir, f'{speaker}.wav')
                if os.path.exists(cand_path):
                    speaker_wav = cand_path
            
            # 计算目标时长
            vad_duration = line.get('vad_duration')
            if vad_duration is not None:
                target_duration = min(float(vad_duration), raw_duration)
            else:
                target_duration = raw_duration
            
            target_duration = max(target_duration, MIN_SAFE_DURATION)
            target_duration = min(target_duration, raw_duration * MAX_DURATION_FACTOR)
            logger.debug(f"🎯 片段 {i}: 目标时长 = {target_duration:.2f}s")
            
            # 生成TTS音频
            start_tts = time.time()
            wav_raw = generate_tts_audio_to_memory(text, speaker_wav, engine, config, target_duration)
            tts_time = time.time() - start_tts
            
            if wav_raw is None:
                logger.warning(f"⚠️ 片段 {i} TTS失败，插入静音")
                wav_adjusted = np.zeros(int(target_duration * config.sample_rate), dtype=np.float32)
            else:
                # 拉伸到目标时长
                wav_adjusted = adjust_audio_length_in_memory(
                    wav_raw,
                    target_duration,
                    config.sample_rate,
                    config.min_speed_factor,
                    config.max_speed_factor
                )
            
            # 写入时间轴（自动截断）
            start_sample = int(start_sec * config.sample_rate)
            end_sample = int(end_sec * config.sample_rate)
            actual_end = min(start_sample + len(wav_adjusted), end_sample, total_samples)
            if actual_end > start_sample:
                full_wav[start_sample:actual_end] = wav_adjusted[:actual_end - start_sample]
            
            logger.info(f"✅ 片段 {i} 完成 ({target_duration:.2f}s) in {tts_time:.2f}s")
        
        # 保存片段文件（可选，用于调试）
        for i, line in enumerate(transcript):
            output_path = os.path.join(output_folder, f'{str(i).zfill(4)}.wav')
            start_sample = int(float(line['start']) * config.sample_rate)
            end_sample = int(float(line['end']) * config.sample_rate)
            segment = full_wav[start_sample:end_sample]
            save_wav(segment, output_path, config.sample_rate)
        
        # 音量归一化
        if os.path.exists(audio_vocals_path):
            try:
                vocal_wav, sr = librosa.load(audio_vocals_path, sr=config.sample_rate)
                if len(vocal_wav) > 0:
                    vocal_max = np.max(np.abs(vocal_wav))
                    if vocal_max > 0 and np.max(np.abs(full_wav)) > 0:
                        full_wav = full_wav / np.max(np.abs(full_wav)) * vocal_max * 0.95
            except Exception as e:
                logger.warning(f"音量参考失败: {e}")
        
        # 保存主TTS音频
        tts_output_path = os.path.join(folder, 'audio_tts.wav')
        save_wav(full_wav, tts_output_path, config.sample_rate)
        logger.info(f"🔊 TTS音频已保存: {tts_output_path}")
        
        # 混合伴奏
        instruments_path = os.path.join(folder, 'audio_instruments.wav')
        if os.path.exists(instruments_path):
            try:
                instruments_wav, sr = librosa.load(instruments_path, sr=config.sample_rate)
                if len(instruments_wav) < len(full_wav):
                    instruments_wav = np.pad(instruments_wav, (0, len(full_wav) - len(instruments_wav)))
                elif len(instruments_wav) > len(full_wav):
                    instruments_wav = instruments_wav[:len(full_wav)]
                combined_wav = full_wav * 0.8 + instruments_wav * 0.6
                combined_output_path = os.path.join(folder, 'audio_combined.wav')
                save_wav_norm(combined_wav, combined_output_path, config.sample_rate)
                logger.info(f"🎧 混合音频已保存: {combined_output_path}")
            except Exception as e:
                logger.error(f"❌ 音频混合失败: {e}")
                return False
        else:
            logger.warning(f"⚠️ 伴奏文件不存在: {instruments_path}")
        
        return True
        
    except Exception as e:
        logger.error(f"💥 音频生成失败: {e}")
        logger.error(traceback.format_exc())
        return False

# === 以下函数保持不变 ===
def generate_all_wavs_under_folder(root_folder: str, 
                                   config: Optional[TTSConfig] = None,
                                   skip_existing: bool = True) -> Dict[str, Any]:
    if config is None:
        config = TTSConfig()
    
    results = {
        'total_folders': 0,
        'processed': 0,
        'success': 0,
        'failed': 0,
        'failed_folders': [],
        'skipped': 0
    }
    
    for root, dirs, files in os.walk(root_folder):
        if 'translation.json' in files:
            results['total_folders'] += 1
            
            if skip_existing and 'audio_combined.wav' in files:
                logger.info(f'⏭️ 跳过已处理: {root}')
                results['skipped'] += 1
                continue
            
            logger.info(f'📁 处理: {root}')
            results['processed'] += 1
            
            success = generate_wavs(root, config)
            if success:
                results['success'] += 1
                logger.info(f'✅ 完成: {root}')
            else:
                results['failed'] += 1
                results['failed_folders'].append(root)
                logger.error(f'❌ 失败: {root}')
    
    return results

def main():
    import argparse
    parser = argparse.ArgumentParser(description='语音合成与音频处理脚本（优化版）')
    parser.add_argument('--folder', type=str, help='要处理的单个文件夹路径')
    parser.add_argument('--all', action='store_true', help='处理指定文件夹下的所有子文件夹')
    parser.add_argument('--root', type=str, default='videos', help='根文件夹路径（默认: videos）')
    parser.add_argument('--force-bytedance', action='store_true', help='强制使用字节跳动TTS')
    parser.add_argument('--skip-existing', action='store_true', help='跳过已存在混合音频的文件夹')
    parser.add_argument('--no-post-speedup', action='store_true', help='禁用后处理加速')
    
    args = parser.parse_args()
    
    config = TTSConfig(
        force_bytedance=args.force_bytedance,
        enable_post_speedup=not args.no_post_speedup
    )
    
    logger.remove()
    logger.add(sys.stdout, level="INFO", format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{message}</cyan>")
    
    if args.all or (not args.folder and not args.all):
        root_dir = args.root if args.all else 'videos'
        logger.info(f"🔄 批量处理所有待处理视频（根目录: {root_dir})")
        results = generate_all_wavs_under_folder(root_dir, config, args.skip_existing)
        logger.info("\n" + "="*50)
        logger.info("📊 处理完成！")
        logger.info(f"总计: {results['total_folders']}")
        logger.info(f"处理: {results['processed']}")
        logger.info(f"成功: {results['success']}")
        logger.info(f"失败: {results['failed']}")
        logger.info(f"跳过: {results['skipped']}")
        if results['failed'] > 0:
            logger.warning(f"失败列表: {results['failed_folders']}")
    elif args.folder:
        logger.info(f"🎬 处理单个: {args.folder}")
        success = generate_wavs(args.folder, config)
        if success:
            logger.info("🎉 完成！")
        else:
            logger.error("💥 失败！")
    else:
        logger.error("❌ 请指定 --folder 或使用默认批量模式（直接运行即可）")

if __name__ == '__main__':
    main()