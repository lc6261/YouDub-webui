
import os
import subprocess
import whisperx
import torch
from whisperx.diarize import DiarizationPipeline

# ==================== 配置区 ====================
HF_TOKEN = "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" 
VIDEO_PATH = r"tempvideo\寰宇新聞 頻道\20251231 北京這套演給誰看 雙城論壇才散場就翻臉軍演 國台辦反嗆 顛倒黑白 嚴禁以武謀獨 寰宇新聞\download.mp4"
VIDEO_PATH = r"tempvideo\零度解说\20251220 Grok 4 1 免费一键生成电影级AI大片 MV 连续故事情节 画面连贯 首尾帧一致 零度解说\download.mp4"
VIDEO_PATH = r"videos\WorldofAI\20251229 Gemini 3 Deep Think Enhancing Gemini to Become a Super Agent Build Automate ANYTHING\download.mp4"

OUTPUT_DIR = "./output"
MODEL_SIZE = "large-v3"      # 可选: tiny/base/small/medium/large-v3
MODEL_SIZE = "small"      # 可选: tiny/base/small/medium/large-v3
DEVICE = "cuda"
# ==============================================

def main():
    # ✅ 启用 TF32 加速
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True

    # 创建输出目录
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    audio_path = os.path.join(OUTPUT_DIR, "audio.wav")

    # 1. 检查并转换路径
    abs_video_path = os.path.abspath(VIDEO_PATH)
    if not os.path.exists(abs_video_path):
        print(f"❌ 错误：找不到视频文件！\n路径：{abs_video_path}")
        return
    # 1. 从视频提取音频
    print("📦 提取音频...")
    try:
        # 使用 capture_output=True 来捕获 ffmpeg 的报错信息
        result = subprocess.run([
            "ffmpeg", "-y", "-i", abs_video_path,
            "-ac", "1", "-ar", "16000",
            "-acodec", "pcm_s16le", audio_path
        ], check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as e:
        print("❌ FFmpeg 报错了：")
        print(e.stderr) # 这里会显示具体的 ffmpeg 错误原因
        return

    # 2. 语音识别（Whisper）
    print("🗣️  语音识别中...")
    model = whisperx.load_model(MODEL_SIZE, DEVICE, compute_type="float16")
    result = model.transcribe(audio_path, batch_size=16)
    detected_language = result["language"]
    print(f"🔤 检测语言: {detected_language}")

    # 3. 词级时间戳对齐
    print("⏱️  对齐时间戳...")
    # 强制重新下载或检查对齐模型
    model_a, metadata = whisperx.load_align_model(language_code=detected_language, device=DEVICE)
    result = whisperx.align(result["segments"], model_a, metadata, audio_path, DEVICE)

    # 4. 说话人分离（Speaker Diarization）
    print("👤 执行说话人分离...")
    diarize_model = DiarizationPipeline(use_auth_token=HF_TOKEN, device=DEVICE)
    diarize_result = diarize_model(audio_path)
    result = whisperx.assign_word_speakers(diarize_result, result)

    result["language"] = detected_language

    # 5. 保存带说话人标签的 SRT 字幕
    print("💾 保存字幕文件...")
    from whisperx.utils import get_writer
    writer = get_writer("srt", OUTPUT_DIR)
    writer(
        result=result,
        audio_path=audio_path,
        options={"max_line_width": None, "max_line_count": None, "highlight_words": False}
    )

    output_srt = os.path.join(OUTPUT_DIR, os.path.splitext(os.path.basename(audio_path))[0] + ".srt")
    print(f"✅ 成功！字幕已生成: {output_srt}")

# 🔥 这里是关键：Windows 必须加这一行
if __name__ == "__main__":
    main()